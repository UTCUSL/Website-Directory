function [ output ] = SeekerAlgorithm(uu,P)
%SEEKER Summary of this function goes here
%   Detailed explanation goes here


persistent xhat
persistent Phat

t = uu(end);

NN = 0;
qx          = uu(NN+1);
qy          = uu(NN+2);
target_size = uu(NN+3);
target_psi  = uu(NN+4);

NN = 4;
UAV.pn     = uu(1+NN);    % north position (m)
UAV.pe     = uu(2+NN);    % east position (m)
UAV.pd     = uu(3+NN);    % position down (negative of altitude) (m)
UAV.u      = uu(4+NN);    % velocity along body x-axis (m/s)
UAV.v      = uu(5+NN);    % velocity along body y-axis (m/s)
UAV.w      = uu(6+NN);    % velocity along body z-axis (m/s)
UAV.phi    = uu(7+NN);   % roll angle (rad)
UAV.theta  = uu(8+NN); % pitch angle  (rad)
UAV.psi    = uu(9+NN);   % yaw angle (rad)
UAV.p      = uu(10+NN);    % roll rate  (rad/s)
UAV.q      = uu(11+NN);    % pitch rate (rad/s)
UAV.r      = uu(12+NN);    % yaw rate (rad/s)

% rotation matrix convering a vector from camera frame to the level frame
% (removing roll)
theta = UAV.theta;
phi   = UAV.phi;

Rot_v1_to_v2 = [...
    cos(theta), 0, -sin(theta);...
    0, 1, 0;...
    sin(theta), 0, cos(theta);...
    ];    
Rot_v2_to_b = [...
    1, 0, 0;...
    0, cos(phi), sin(phi);...
    0, -sin(phi), cos(phi);...
    ];
R_b_c = [...    % body to camera -- azimuth and elevation angles are zeros.
    0, 1, 0;...
    0, 0, 1;...
    1, 0, 0];

R_v1_c = R_b_c*Rot_v2_to_b*Rot_v1_to_v2;

p_tgt_c  = [qx;qy;P.f];
p_tgt_v1 = R_v1_c' * p_tgt_c;

eta = atan2(p_tgt_v1(2),p_tgt_v1(1));
xi  = -atan(p_tgt_v1(3)/sqrt(p_tgt_v1(2)^2+p_tgt_v1(1)^2));

% coordinats in the local-level frame
%
% R_c_level = [ cos(UAV.phi) sin(UAV.phi);...
%     -sin(UAV.phi) cos(UAV.phi)];
% p_c_prime = R_c_level*[qx;-qy];
% UAV.theta = asin(UAV.hdot/UAV.Va);
% eta = atan(p_c_prime(1)/P.f);
% xi  = atan(p_c_prime(2)/sqrt(P.f*P.f+p_c_prime(1)*p_c_prime(1))) ...
%     + atan(tan(UAV.theta)*cos(eta));
% xi_deg = xi*180/pi
% eta_deg = eta*180/pi
UAV.Va = sqrt(UAV.u^2 + UAV.v^2 + UAV.w^2);
UAV.psidot = P.g/UAV.Va*tan(UAV.phi);

z = [eta;xi];  % measurements (from camera): eta-azimuth angle, xi-elevation angle

%initialize Kalman filter
% if t<P.Ts,
%     xhat = P.xhat0;
%     Phat = P.Phat0;
% end

% prediction step
% [xhat, Phat] = ekf_predict(xhat, Phat,UAV,P);
% 
% % measurement update
% [xhat, Phat] = ekf_update(z, xhat, Phat, P);
% 
% dis = UAV.Va/xhat(1);
% output = [xhat;Phat(1,1); Phat(2,2); Phat(3,3);0];

output = [1;eta;xi;zeros(4,1)];
end

function [xhat, Phat] = ekf_predict(xhat, Phat, UAV, P)


N = 5;
for i = 1:N
    
    kappa = xhat(1);
    eta   = xhat(2);
    xi    = xhat(3);
    
    f = [kappa^2*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi)); ...
         kappa*cos(UAV.theta)*sin(eta)/cos(xi)-UAV.psidot;...
         kappa  *(cos(UAV.theta)*cos(eta)*sin(xi)-sin(UAV.theta)*cos(xi))];
    
    A11 = 2*kappa*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi));
    A12 = -kappa^2*cos(UAV.theta)*sin(eta)*cos(xi);
    A13 = kappa^2*(-cos(UAV.theta)*cos(eta)*sin(xi)+sin(UAV.theta)*cos(xi));
    
    A21 = cos(UAV.theta)*sin(eta)/cos(xi);
    A22 = kappa*cos(UAV.theta)*cos(eta)/cos(xi);
    A23 = kappa*cos(UAV.theta)*sin(eta)/(cos(xi)^2)*sin(xi);
    
    A31 = cos(UAV.theta)*cos(eta)*sin(xi)-sin(UAV.theta)*cos(xi);
    A32 = -kappa*cos(UAV.theta)*sin(eta)*sin(xi);
    A33 =  kappa*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi));
    
    A = [A11 A12 A13;...
        A21 A22 A23;...
        A31 A32 A33];
    
    xhat = xhat+ P.Ts/N * f;
%     

%     
%     if xhat(1)>P.UAV.V/P.dis_UAV_tegart_min
%         xhat(1) = P.UAV.V/P.dis_UAV_tegart_min;
% 
%     end
    
    Phat = Phat + P.Ts/N*(A*Phat + Phat*A' + P.Q);
    %         QQ = eye(4)*1; Phat = Phat + P.Ts/N*(A*Phat + Phat*A' +QQ);
    
end
%     xhat(1) = abs(xhat(1));


end

%%
% ekf measurement update
%
function [xhat, Phat] = ekf_update(z, xhat, Phat, P)
C = [0 1 0;...
    0 0 1];
h_x = xhat(2:3);
K = Phat*C'/(C*Phat*C'+P.R);
Phat = (eye(3)-K*C)*Phat;
xhat = xhat + K*(z-h_x);

% xhat(1) = abs(xhat(1));

% if xhat(1)>P.UAV.V/P.dis_UAV_tegart_min
%     xhat(1) = P.UAV.V/P.dis_UAV_tegart_min;
% end
end