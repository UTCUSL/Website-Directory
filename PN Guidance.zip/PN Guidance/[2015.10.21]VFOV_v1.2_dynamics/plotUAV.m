function [sys,x0,str,ts] = plotUAV(t,x,u,flag,P)

persistent movie_clip 

%
% Modified:
% 08/10/2014 Liang Sun

switch flag,
    
    %%%%%%%%%%%%%%%%%%
    % Initialization %
    %%%%%%%%%%%%%%%%%%
    case 0,
        [sys,x0,str,ts,movie_clip] = mdlInitializeSizes(P);
        
        %%%%%%%%%%
        % Update %
        %%%%%%%%%%
    case 2,
        [sys,movie_clip] = mdlUpdate(t,x,u,P,movie_clip);
        
        %%%%%%%%%%
        % Output %
        %%%%%%%%%%
    case 3,
        sys = [];
        
        %%%%%%%%%%%%%
        % Terminate %
        %%%%%%%%%%%%%
    case 9,
        sys = []; % do nothing
        
        %%%%%%%%%%%%%%%%%%%%
        % Unexpected flags %
        %%%%%%%%%%%%%%%%%%%%
    otherwise
        error(['unhandled flag = ',num2str(flag)]);
end

%end dsfunc

%
%=======================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=======================================================================
%
function [sys,x0,str,ts,movie_clip] = mdlInitializeSizes(P)

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 6+P.UAV.N*2+1; 
sizes.NumOutputs     = 0;
sizes.NumInputs      = 4+7+12*P.UAV.N+7;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);

x0 = zeros(sizes.NumDiscStates,1);

movie_clip.fig_handle = 1;
movie_clip.time_step = 1;
% movie_clip.frame = getframe;

str = [];
ts  = [P.Ts 0];

% end mdlInitializeSizes
%
%=======================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=======================================================================
%
function [xup,movie_clip] = mdlUpdate(t,x,uu,P,movie_clip)

initialize    = x(1);       % initial graphics
fig_target    = x(2);       % target figure handle
fig_cam_obj   = x(3);       % position figure handle
fig_sphere    = x(4);       % Sphere figure handle
fig_vector    = x(5);       % vector from target to UAV
fig_circle    = x(6);       % circle for path planning
fig_est_target = x(7);      % estimited target location in 3D

NN = 7;
fig_UAV = x(NN+1:NN+P.UAV.N);       % UAV figure handle
fig_fov = x(NN+P.UAV.N+1:NN+P.UAV.N+P.UAV.N);

NN = 0;
qx            = uu(1+NN);       % pixel x location
qy            = uu(2+NN);       % pixel y location
qsize         = uu(3+NN);       % pixel size
qpsi          = uu(4+NN);       % target orientation in image
% 
NN = NN + 4;
tn            = uu(1+NN);       % target x location
te            = uu(2+NN);       % target y location
td            = uu(3+NN);       % target z location
tpsi          = uu(5+NN);       % target orientation in inertial frame

az = P.az;
el = P.el;

target.n = tn;
target.e = te;
target.d = td;
target.psi = tpsi;

%% target estimation information

%% UAV inertial position             
NN = 4+7;
UAV.pn     = uu(1+NN);    % north position (m)
UAV.pe     = uu(2+NN);    % east position (m)
UAV.pd     = uu(3+NN);    % position down (negative of altitude) (m)
UAV.u      = uu(4+NN);    % velocity along body x-axis (m/s)
UAV.v      = uu(5+NN);    % velocity along body y-axis (m/s)
UAV.w      = uu(6+NN);    % velocity along body z-axis (m/s)
UAV.phi    = uu(7+NN);   % roll angle (rad)
UAV.theta  = uu(8+NN); % pitch angle  (rad)
UAV.psi    = uu(9+NN);   % yaw angle (rad)
UAV.p      = uu(10+NN);    % roll rate  (rad/s)
UAV.q      = uu(11+NN);    % pitch rate (rad/s)
UAV.r      = uu(12+NN);    % yaw rate (rad/s)

UAV.h = -UAV.pd;

wn = 0;
we = 0;
UAV.Va = sqrt(UAV.u^2 + UAV.v^2 + UAV.w^2);
Va_g = sqrt(UAV.u^2 + UAV.v^2);
VN = Va_g*cos(UAV.psi)+wn;
VE = Va_g*sin(UAV.psi)+we;
UAV.Vg     = sqrt(VN^2 + VE^2);
UAV.chi = atan2(VE, VN);
UAV.gam = atan2(UAV.w, UAV.Vg);

%%
NN = 4+7+12*P.UAV.N;
kappa = abs(uu(NN+1));
eta   = uu(NN+2);
xi    = uu(NN+3);

dis = UAV.Va/kappa;
relative_location = [ dis*cos(xi)*cos(eta);...
                      dis*cos(xi)*sin(eta);...
                     -dis*sin(xi)];

target_position = [UAV.pn;UAV.pe;-UAV.h]+relative_location;

target_est.n = target_position(1);
target_est.e = target_position(2);
target_est.d = target_position(3);
target_est.psi = tpsi;
target_est.sigma = 30+2*sin(t);

if initialize==0,
    % initialize the plot
        initialize = 1;
    figure(movie_clip.fig_handle);
    clf(movie_clip.fig_handle);   
   
    
    %% plot path planning circle
%     fig_circle = drawPathPlanCircle(target_est,P,[],'b','normal'); hold on
    
    for i=1:P.UAV.N
        NN = 4+7+(i-1)*12;
        UAV.pn     = uu(1+NN);    % north position (m)
        UAV.pe     = uu(2+NN);    % east position (m)
        UAV.pd     = uu(3+NN);    % position down (negative of altitude) (m)
        UAV.u      = uu(4+NN);    % velocity along body x-axis (m/s)
        UAV.v      = uu(5+NN);    % velocity along body y-axis (m/s)
        UAV.w      = uu(6+NN);    % velocity along body z-axis (m/s)
        UAV.phi    = uu(7+NN);   % roll angle (rad)
        UAV.theta  = uu(8+NN); % pitch angle  (rad)
        UAV.psi    = uu(9+NN);   % yaw angle (rad)
        UAV.p      = uu(10+NN);    % roll rate  (rad/s)
        UAV.q      = uu(11+NN);    % pitch rate (rad/s)
        UAV.r      = uu(12+NN);    % yaw rate (rad/s)
        
        UAV.h = -UAV.pd;
        
        wn = 0;
        we = 0;
        UAV.Va = sqrt(UAV.u^2 + UAV.v^2 + UAV.w^2);
        Va_g = sqrt(UAV.u^2 + UAV.v^2);
        VN = Va_g*cos(UAV.psi)+wn;
        VE = Va_g*sin(UAV.psi)+we;
        UAV.Vg     = sqrt(VN^2 + VE^2);
        UAV.chi = atan2(VE, VN);
        UAV.gam = atan2(UAV.w, UAV.Vg);
        
        
        fig_UAV(i) = drawUAV(UAV.pn, UAV.pe, -UAV.h, UAV.phi, UAV.theta, UAV.psi, [], 'normal');
        hold on
        fig_fov(i) = drawFov(UAV.pn, UAV.pe, -UAV.h, UAV.phi, UAV.theta, UAV.psi,az,el,P.cam_fov,[],'normal');
        hold on
    end
    xlabel('East (m)','fontsize',16)
    ylabel('North (m)','fontsize',16)
    zlabel('Altitude (m)','fontsize',16)
    title('3D View','fontsize',16)
    hold on
    % plot waypoints
    % ground target
    plot3(P.target_waypoints(:,2), P.target_waypoints(:,1), zeros(size(P.target_waypoints(:,1))));hold on
    fig_target     = targetPlot(tn,te,td,tpsi,P.target_size,[],'r','normal');hold on
%     fig_est_target = targetPlot(target_est.n,target_est.e,target_est.d,tpsi,P.target_size,[],'b','normal');hold on

    %     title('Attitude (roll, pitch, yaw)')
    view(-45,45)
    
    axis([P.xmin,P.xmax,P.ymin,P.ymax,P.zmin,P.zmax]);
    %    view(0,90)  % top down view to check heading hold loop
    %    view(0,0)   % side view to check altitude hold loop
    grid on
    
    % plot camera view
    figure(2),clf(2)
    %     handle=subplot('position',[0.61, 0.61, 0.3, 0.3]);
    tmp = P.cam_pix/2;
    %         set(handle,'XAxisLocation','top','XLim',[-tmp,tmp],'YLim',[-tmp,tmp]);
    tmp_virtual = 5*tmp;
    
    vertActFOV = [tmp tmp;tmp -tmp;-tmp -tmp;-tmp tmp;tmp tmp;];
    % plot virtual field of view
    plot(vertActFOV(:,1),vertActFOV(:,2),'-.');
    hold on
    fig_cam_obj = targetCamPlot(qx,qy,0,qpsi,qsize,[],'r','normal');hold on
    axis ([-tmp_virtual tmp_virtual -tmp_virtual tmp_virtual])
    xlabel('px (pixels)','fontsize',16)
    ylabel('py (pixels)','fontsize',16)
    title('Virtual Camera View','fontsize',16)
    legend('Actual Camera Range')
    
    %% Plot sphere view
%     figure(3),clf(3)
%     [x,y,z] = sphere(50);
%     scale = 0.2;
%     arrowHeadSize = 0.5;
%     lineWidth = 1;
%     quiver3(0,0,0,0,P.f,0,scale,'linewidth',lineWidth,'color','k','MaxHeadSize',arrowHeadSize);hold on;
%     quiver3(0,0,0,P.f,0,0,scale,'linewidth',lineWidth,'color','r','MaxHeadSize',arrowHeadSize);hold on;
%     quiver3(0,0,0,0,0,-P.f,scale,'linewidth',lineWidth ,'color','g','MaxHeadSize',arrowHeadSize);hold on;
%     
%     legend('Front','Right Wing','Down')
%     
%     range = P.f;
% 
%     x = x*range;
%     y = y*range;
%     z = z*range;
%     
%     lightGrey = 0.8*[1 1 1]; % It looks better if the lines are lighter
% %     surface(x,y,z,'FaceColor', 'none','EdgeColor',lightGrey)
%     surface(x,y,z,'FaceColor', 'none','EdgeColor',lightGrey)    
%     hold on
%     % calculate the projection of the target onto the sphere
%     
%  
%     fig_sphere = drawProjectionOnSphere(target,UAV,P.target_size,P,[],'r','normal');hold on;
%     fig_vector = drawVectorTargetUAV(target,UAV,P,[],'b','normal');hold on;
%     grid on;
%     xlabel('East','fontsize',16)
%     ylabel('North','fontsize',16)
%     zlabel('Altitude','fontsize',16)
%     title('Sphere Camera View','fontsize',16)
%     legend('Actual Camera View')
    
    
else  % do this at every time step
%     drawPathPlanCircle(target_est,P,fig_circle);hold on
    % plot UAV
    for i=1:P.UAV.N
        NN = 4+7+(i-1)*12;
        UAV.pn     = uu(1+NN);    % north position (m)
        UAV.pe     = uu(2+NN);    % east position (m)
        UAV.pd     = uu(3+NN);    % position down (negative of altitude) (m)
        UAV.u      = uu(4+NN);    % velocity along body x-axis (m/s)
        UAV.v      = uu(5+NN);    % velocity along body y-axis (m/s)
        UAV.w      = uu(6+NN);    % velocity along body z-axis (m/s)
        UAV.phi    = uu(7+NN);   % roll angle (rad)
        UAV.theta  = uu(8+NN); % pitch angle  (rad)
        UAV.psi    = uu(9+NN);   % yaw angle (rad)
        UAV.p      = uu(10+NN);    % roll rate  (rad/s)
        UAV.q      = uu(11+NN);    % pitch rate (rad/s)
        UAV.r      = uu(12+NN);    % yaw rate (rad/s)
        
        UAV.h = -UAV.pd;
        
        wn = 0;
        we = 0;
        UAV.Va = sqrt(UAV.u^2 + UAV.v^2 + UAV.w^2);
        Va_g = sqrt(UAV.u^2 + UAV.v^2);
        VN = Va_g*cos(UAV.psi)+wn;
        VE = Va_g*sin(UAV.psi)+we;
        UAV.Vg     = sqrt(VN^2 + VE^2);
        UAV.chi = atan2(VE, VN);
        UAV.gam = atan2(UAV.w, UAV.Vg);
        
        
        drawUAV(UAV.pn, UAV.pe, -UAV.h, UAV.phi, UAV.theta, UAV.psi, fig_UAV(i));hold on;
        drawFov(UAV.pn, UAV.pe, -UAV.h, UAV.phi, UAV.theta, UAV.psi,az,el,P.cam_fov,fig_fov(i));hold on
    end
        targetPlot(tn,te,td,tpsi,P.target_size,fig_target);hold on
%         targetPlot(target_est.n,target_est.e,target_est.d,tpsi,P.target_size,fig_est_target);hold on
        % plot camera view
        targetCamPlot(qx,qy,0,qpsi,qsize,fig_cam_obj);hold on        

%         drawProjectionOnSphere(target,UAV,P.target_size,P,fig_sphere);hold on;
%         drawVectorTargetUAV(target,UAV,P,fig_vector);hold on;   
end

xup(1) = initialize;
xup(2) = fig_target;
xup(3) = fig_cam_obj;
xup(4) = fig_sphere;
xup(5) = fig_vector;
xup(6) = fig_circle;
xup(7) = fig_est_target;
xup(8) = fig_UAV;
xup(9) = fig_fov;

% xup = [initialize; fig_target; fig_cam_obj;fig_sphere;fig_vector;fig_circle;fig_est_target;fig_UAV;fig_fov];


%end mdlUpdate

%% Draw path planning circle for UAV
function handle = drawPathPlanCircle(target,P,handle,color,mode)
h_desired = P.path.aa*target.sigma;
circle_radius = P.path.cc*target.sigma;

alpha = 0:0.1:2*pi;
X = target.n+circle_radius*cos(alpha);
Y = target.e+circle_radius*sin(alpha);
Z = -h_desired*ones(size(alpha));
X = [X,X(1)];
Y = [Y,Y(1)];
Z = [Z,Z(1)];

if isempty(handle),
    %    handle = patch(X, Y, Z, color, 'EraseMode', mode);
%     handle = plot3(Y, X, -Z, color, 'EraseMode', mode);
    handle = plot3(Y, X, -Z,'linewidth',2,'color',color, 'EraseMode', mode);
else
    %    set(handle,'XData',X,'YData',Y,'ZData',Z);
%     set(handle,'XData',Y,'YData',X,'ZData',-Z);
    set(handle,'XData',Y,'YData',X,'ZData',-Z);
    drawnow
end

%% draw arrow from the orgin to the target in UAV body frame
function handle = drawVectorTargetUAV(target,uav,P,handle,color,mode)
X = target.n;
Y = target.e;
Z = target.d;
p_t = [X;Y;Z];
% uav inertial NED cooridnates
p_u = [uav.n;uav.e;uav.d];
% translate by -p_u (see definition of translateXYZ())
[X,Y,Z] = translateXYZ(X,Y,Z,-p_u');

% target coordinates in body frame
PTS_v = [X Y Z]';
PTS_b = Rot_v_to_b(uav.phi,uav.theta,uav.psi)*PTS_v;
% PTS_b = PTS_b';

Norm = sqrt(PTS_b(1,:).^2+PTS_b(2,:).^2+PTS_b(3,:).^2);

PTS_b_unit = PTS_b./repmat(Norm,3,1);

PTS_sphere = P.f*PTS_b_unit;

% PTS_sphere = PTS_sphere;

X = PTS_sphere(1);
Y = PTS_sphere(2);
Z = PTS_sphere(3);

% Scale the arrow depending on the distance between the target and the UAV
dis = norm(p_u-p_t);
range = 600; % the distance corresponding scale 1 in quiver
scale = dis/range;
X = scale*X;
Y = scale*Y;
Z = scale*Z;

if isempty(handle),
    %    handle = patch(X, Y, Z, color, 'EraseMode', mode);
%     handle = plot3(Y, X, -Z, color, 'EraseMode', mode);
    handle = quiver3(0,0,0,Y, X, -Z,'linewidth',3,'color',color, 'EraseMode', mode,'MaxHeadSize',0.7);
else
    %    set(handle,'XData',X,'YData',Y,'ZData',Z);
%     set(handle,'XData',Y,'YData',X,'ZData',-Z);
    set(handle,'UData',Y,'VData',X,'WData',-Z);
    drawnow
end


%% draw the projection of the target onto the sphere field of view
function handle = drawProjectionOnSphere(target,uav,size,P,handle,color,mode)
tn = target.n;
te = target.e;
td = target.d;
tpsi = target.psi;

% get the target data points
[X,Y,Z] = targetXYZ;

% scale by size
X = X*size;
Y = Y*size;
Z = Z*size;

% rotate by tpsi
[X,Y,Z] = rotateXYZ(X,Y,Z,0,0,tpsi);

% translate by [tn, te, td]
[X,Y,Z] = translateXYZ(X,Y,Z,[tn,te,td]);

% uav inertial NED cooridnates
p_u = [uav.n;uav.e;uav.d];
% translate by -p_u (see definition of translateXYZ())
[X,Y,Z] = translateXYZ(X,Y,Z,-p_u');

% target coordinates in body frame
PTS_v = [X Y Z]';
PTS_b = Rot_v_to_b(uav.phi,uav.theta,uav.psi)*PTS_v;
% PTS_b = PTS_b';

Norm = sqrt(PTS_b(1,:).^2+PTS_b(2,:).^2+PTS_b(3,:).^2);

PTS_b_unit = PTS_b./repmat(Norm,3,1);

PTS_sphere = P.f*PTS_b_unit;

PTS_sphere = PTS_sphere';

X = PTS_sphere(:,1);
Y = PTS_sphere(:,2);
Z = PTS_sphere(:,3);

if isempty(handle),
    %    handle = patch(X, Y, Z, color, 'EraseMode', mode);
    handle = patch(Y, X, -Z, color, 'EraseMode', mode);
else
    %    set(handle,'XData',X,'YData',Y,'ZData',Z);
    set(handle,'XData',Y,'YData',X,'ZData',-Z);
    drawnow
end

%% ---------------------------------------------------------------------
%----------------------------------------------------------------------
% User defined functions
%----------------------------------------------------------------------
%----------------------------------------------------------------------
function handle = drawFov(pn, pe, pd, phi, theta, psi,az,el,cam_fov,handle, mode)
                           

    %-------vertices and faces for camera field-of-view --------------
    % vertices
    % define unit vectors along fov in the camera gimbal frame
    pts = [...
        cos(cam_fov/2)*cos(cam_fov/2),  sin(cam_fov/2)*cos(cam_fov/2), -sin(cam_fov/2);...
        cos(cam_fov/2)*cos(cam_fov/2), -sin(cam_fov/2)*cos(cam_fov/2), -sin(cam_fov/2);...
        cos(cam_fov/2)*cos(cam_fov/2), -sin(cam_fov/2)*cos(cam_fov/2),  sin(cam_fov/2);...
        cos(cam_fov/2)*cos(cam_fov/2),  sin(cam_fov/2)*cos(cam_fov/2),  sin(cam_fov/2);...
        ]';
    % transform from gimbal coordinates to the vehicle coordinates
    pts = Rot_v_to_b(phi,theta,psi)'*Rot_b_to_g(az,el)'*pts;

    % first vertex is at center of MAV vehicle frame
    Vert = [pn, pe, pd];  
    % project field of view lines onto ground plane and make correction
    % when the projection is above the horizon
    for i=1:4,
        % alpha is the angle that the field-of-view line makes with horizon
        alpha = atan2(pts(3,i),norm(pts(1:2,i)));
        if alpha > 0,
            % this is the normal case when the field-of-view line
            % intersects ground plane
            Vert = [...
                Vert;...
                [pn-pd*pts(1,i)/pts(3,i), pe-pd*pts(2,i)/pts(3,i), 0];...
                ];
        else
            % this is when the field-of-view line is above the horizon.  In
            % this case, extend to a finite, but far away (9999) location.
            Vert = [...
                Vert;...
                [pn+99999*pts(1,i), pe+99999*pts(2,i),0];...
            ];
        end
    end

    Faces = [...
          1, 1, 2, 2;... % x-y face
          1, 1, 3, 3;... % x-y face
          1, 1, 4, 4;... % x-y face
          1, 1, 5, 5;... % x-y face
          2, 3, 4, 5;... % x-y face
        ];

    edgecolor      = [1, 1, 1]; % black
    footprintcolor = [1,1,0];%[1,0,1];%[1,1,0];
    % define colors for faces
    drawParam.myred = [1, 0, 0];
    drawParam.mygreen = [0, 1, 0];
    drawParam.myblue = [0, 0, 1];
    drawParam.myyellow = [1,1,0];
    colors = [edgecolor; edgecolor; edgecolor; edgecolor; footprintcolor];  
    colors_fov = [drawParam.myyellow; drawParam.myyellow; drawParam.myyellow; drawParam.myyellow; drawParam.myyellow];
  % transform vertices from NED to XYZ (for matlab rendering)
  R = [...
      0, 1, 0;...
      1, 0, 0;...
      0, 0, -1;...
      ];
  Vert = Vert*R;

  if isempty(handle),
    handle = patch('Vertices', Vert, 'Faces', Faces,...
                 'FaceVertexCData',colors_fov,...
                 'FaceColor','flat',...
                 'EraseMode', mode);
  else
    set(handle,'Vertices',Vert,'Faces',Faces);
  end
  
 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function handle = drawUAV(...
    pn, pe, pd, phi, theta, psi,...
    handle, mode)
[V, F, colors] = UAVVertFace;

V = rotate(V', phi, theta, psi)';  % rotate rigid body
V = translate(V', pn, pe, pd)';  % translate after rotation

% transform vertices from NED to XYZ (for matlab rendering)
R = [...
    0, 1, 0;...
    1, 0, 0;...
    0, 0, -1;...
    ];
V = V*R;

if isempty(handle),
    handle = patch('Vertices', V, 'Faces', F,...
        'FaceVertexCData',colors,...
        'FaceColor','flat',...
        'EraseMode', mode);
else
    set(handle,'Vertices',V,'Faces',F);
    drawnow
end




%%%%%%%%%%%%%%%%%%%%%%%
function XYZ=rotate(XYZ,phi,theta,psi)
  % define rotation matrix
  R_roll = [...
          1, 0, 0;...
          0, cos(phi), -sin(phi);...
          0, sin(phi), cos(phi)];
  R_pitch = [...
          cos(theta), 0, sin(theta);...
          0, 1, 0;...
          -sin(theta), 0, cos(theta)];
  R_yaw = [...
          cos(psi), -sin(psi), 0;...
          sin(psi), cos(psi), 0;...
          0, 0, 1];

  % rotate vertices
  XYZ = R_yaw*R_pitch*R_roll*XYZ;
%   XYZ  = R_roll*R_pitch*R_yaw*XYZ;
  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% translate vertices by pn, pe, pd
function XYZ = translate(XYZ,pn,pe,pd)

  XYZ = XYZ + repmat([pn;pe;pd],1,size(XYZ,2));
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [V, F, colors] = UAVVertFace
% Vertices = [x,y,z] position of each vertex
% Faces = defines how the vertices are connnected for form faces.  Each set
% of our vertices defines one face.


% % parameters for drawing aircraft
  % scale size
  size = 2;
  fuse_l1    = 7;
  fuse_l2    = 4;
  fuse_l3    = 15;
  fuse_w     = 2;
  wing_l     = 6;
  wing_w     = 20;
  tail_l     = 3;
  tail_h     = 3;
  tailwing_w = 10;
  tailwing_l = 3;
  % colors
  red     = [1, 0, 0];
  green   = [0, 1, 0];
  blue    = [0, 0, 1];
  yellow  = [1,1,0];
  magenta = [0, 1, 1];
  

% define vertices and faces for aircraft
  V = [...
    fuse_l1,             0,             0;...        % point 1
    fuse_l2,            -fuse_w/2,     -fuse_w/2;... % point 2     
    fuse_l2,             fuse_w/2,     -fuse_w/2;... % point 3     
    fuse_l2,             fuse_w/2,      fuse_w/2;... % point 4
    fuse_l2,            -fuse_w/2,      fuse_w/2;... % point 5
   -fuse_l3,             0,             0;...        % point 6
    0,                   wing_w/2,      0;...        % point 7
   -wing_l,              wing_w/2,      0;...        % point 8
   -wing_l,             -wing_w/2,      0;...        % point 9
    0,                  -wing_w/2,      0;...        % point 10
   -fuse_l3+tailwing_l,  tailwing_w/2,  0;...        % point 11
   -fuse_l3,             tailwing_w/2,  0;...        % point 12
   -fuse_l3,            -tailwing_w/2,  0;...        % point 13
   -fuse_l3+tailwing_l, -tailwing_w/2,  0;...        % point 14
   -fuse_l3+tailwing_l,  0,             0;...        % point 15
   -fuse_l3+tailwing_l,  0,             -tail_h;...  % point 16
   -fuse_l3,             0,             -tail_h;...  % point 17
  ];
  
  F = [...
        1,  2,  3,  1;... % nose-top
        1,  3,  4,  1;... % nose-left
        1,  4,  5,  1;... % nose-bottom
        1,  5,  2,  1;... % nose-right
        2,  3,  6,  2;... % fuselage-top
        3,  6,  4,  3;... % fuselage-left
        4,  6,  5,  4;... % fuselage-bottom
        2,  5,  6,  2;... % fuselage-right
        7,  8,  9, 10;... % wing
       11, 12, 13, 14;... % tailwing
        6, 15, 17, 17;... % tail
        
  ];  
  
  colors = [...
        yellow;... % nose-top
        yellow;... % nose-left
        yellow;... % nose-bottom
        yellow;... % nose-right
        blue;... % fuselage-top
        blue;... % fuselage-left
        red;... % fuselage-bottom
        blue;... % fuselage-right
        green;... % wing
        green;... % tailwing
        blue;... % tail
    ];

  V = size*V;   % rescale vertices

% end UAVVertFace

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Vert_rails, Face_rails, colors_rails] = railVertFace(drawParam)
% Vertices = [x,y,z] position of each vertex
% Faces = defines how the vertices are connnected for form faces.  Each set
% of our vertices defines one face.

%-------vertices and faces for rails--------------
% vertices for right rail
Vert_rail_right = [...
    drawParam.w/2+drawParam.l, drawParam.l_rail/2, drawParam.w_rail;...
    drawParam.w/2+drawParam.l, drawParam.l_rail/2, 0;...
    drawParam.w/2+drawParam.l, -drawParam.l_rail/2, 0;...
    drawParam.w/2+drawParam.l, -drawParam.l_rail/2, drawParam.w_rail;...
    drawParam.w/2+drawParam.l+drawParam.w_rail, drawParam.l_rail/2, 0;...
    drawParam.w/2+drawParam.l+drawParam.w_rail, -drawParam.l_rail/2, 0;...
    ];
Face_rail_right = [...
    1, 2, 3, 4;... % x-y face
    5, 2, 3, 6;... % x-z face
    ];

% vertices for left rail
Vert_rail_left = Vert_rail_right*[-1,0,0;0,1,0;0,0,1];
Face_rail_left = 6 + [...
    1, 2, 3, 4;... % x-y face
    5, 2, 3, 6;... % x-z face
    ];

% collect vertices and faces
Vert_rails = [Vert_rail_right; Vert_rail_left];
Face_rails = [Face_rail_right; Face_rail_left];

colors_rails = [...
    drawParam.myyellow;...% right rail
    drawParam.myyellow;...%
    drawParam.myyellow;...% left rail
    drawParam.myyellow;...%
    ];

% end railVertFace

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Vert_fov, Face_fov, colors_fov] = fovVertFace(pd,phi,theta,psi,drawParam,C)

%-------vertices and faces for camera field-of-view --------------
% vertices
Vert_fov = pd*[...
    0, 0, 0;...
    tan( phi+C.cam_fov/2), tan(-theta+C.cam_fov/2), 1;...
    tan( phi+C.cam_fov/2), tan(-theta-C.cam_fov/2), 1;...
    -tan(-phi+C.cam_fov/2), tan(-theta+C.cam_fov/2), 1;...
    -tan(-phi+C.cam_fov/2), tan(-theta-C.cam_fov/2), 1;...
    ];
Vert_fov = rotateVert(Vert_fov,0,0,-psi);
Face_fov = [...
    1, 1, 2, 2;... % x-y face
    1, 1, 3, 3;... % x-y face
    1, 1, 4, 4;... % x-y face
    1, 1, 5, 5;... % x-y face
    2, 3, 5, 4;... % x-y face
    ];

colors_fov = [drawParam.myblue; drawParam.myblue; drawParam.myblue; drawParam.myblue; drawParam.myyellow];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X,Y,Z] = targetXYZ

z = -0.01;
pts = [...
    2,  0, z;...
    0,  2, z;...
    0,  1, z;...
    -2,  1, z;...
    -2, -1, z;...
    0, -1, z;...
    0, -2, z;...
    2,  0, z;...
    ];
X = pts(:,1);
Y = pts(:,2);
Z = pts(:,3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function handle = targetPlot(tn,te,td,tpsi,size,handle,color,mode)

% get the target data points
[X,Y,Z] = targetXYZ;

% scale by size
X = X*size;
Y = Y*size;
Z = Z*size;

% rotate by tpsi
[X,Y,Z] = rotateXYZ(X,Y,Z,0,0,tpsi);

% translate by [tn, te, td]
[X,Y,Z] = translateXYZ(X,Y,Z,[tn,te,td]);

if isempty(handle),
    %    handle = patch(X, Y, Z, color, 'EraseMode', mode);
    handle = patch(Y, X, -Z, color, 'EraseMode', mode);
else
    %    set(handle,'XData',X,'YData',Y,'ZData',Z);
    set(handle,'XData',Y,'YData',X,'ZData',-Z);
    drawnow
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function handle = targetCamPlot(tn,te,td,tpsi,size,handle,color,mode)

% get the target data points
[X,Y,Z] = targetXYZ;

% scale by size
X = X*size;
Y = Y*size;
Z = Z*size;

% rotate by tpsi
[X,Y,Z] = rotateXYZ(X,Y,Z,0,0,tpsi);

% translate by [tn, te, td]
[X,Y,Z] = translateXYZ(X,Y,Z,[tn,te,td]);

if isempty(handle),
    handle = patch(X, -Y, -Z, color, 'EraseMode', mode);
else
    set(handle,'XData',X,'YData',-Y,'ZData',-Z);
    drawnow
end

function R = Rot_v_to_b(phi,theta,psi);
% Rotation matrix from body coordinates to vehicle coordinates

Rot_v_to_v1 = [...
    cos(psi), sin(psi), 0;...
    -sin(psi), cos(psi), 0;...
    0, 0, 1;...
    ];
    
Rot_v1_to_v2 = [...
    cos(theta), 0, -sin(theta);...
    0, 1, 0;...
    sin(theta), 0, cos(theta);...
    ];
    
Rot_v2_to_b = [...
    1, 0, 0;...
    0, cos(phi), sin(phi);...
    0, -sin(phi), cos(phi);...
    ];
    
R = Rot_v2_to_b * Rot_v1_to_v2 * Rot_v_to_v1;



%%%%%%%%%%%%%%%%%%%%%%%
function R = Rot_b_to_g(az,el);
% Rotation matrix from body coordinates to gimbal coordinates
Rot_b_to_g1 = [...
    cos(az), sin(az), 0;...
    -sin(az), cos(az), 0;...
    0, 0, 1;...
    ];

Rot_g1_to_g = [...
    cos(el), 0, -sin(el);...
    0, 1, 0;...
    sin(el), 0, cos(el);...
    ];

R = Rot_g1_to_g * Rot_b_to_g1;


%%%%%%%%%%%%%%%%%%%%%%%
function [X,Y,Z]=rotateXYZ(X,Y,Z,phi,theta,psi);
  % define rotation matrix
  R_roll = [...
          1, 0, 0;...
          0, cos(phi), -sin(phi);...
          0, sin(phi), cos(phi)];
  R_pitch = [...
          cos(theta), 0, sin(theta);...
          0, 1, 0;...
          -sin(theta), 0, cos(theta)];
  R_yaw = [...
          cos(psi), -sin(psi), 0;...
          sin(psi), cos(psi), 0;...
          0, 0, 1];
  R = R_roll'*R_pitch'*R_yaw';

  % rotate vertices
  pts = [X, Y, Z]*R;
  X = pts(:,1);
  Y = pts(:,2);
  Z = pts(:,3);
  
% end rotateVert

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% translate vertices by column vector T
function [X,Y,Z] = translateXYZ(X,Y,Z,T)

  X = X + T(1)*ones(size(X));
  Y = Y + T(2)*ones(size(Y));
  Z = Z + T(3)*ones(size(Z));