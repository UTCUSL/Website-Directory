function output = TrackingFilter( uu,P )
%TrackingFilter Summary of this function goes here
%   Detailed explanation goes here
NN = 0;
t = uu(NN+1);

NN = NN+1;
output = uu(NN+1:NN+7);

end

