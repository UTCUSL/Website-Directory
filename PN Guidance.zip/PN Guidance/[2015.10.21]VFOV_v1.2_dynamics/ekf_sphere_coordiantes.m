%% Extended Kalman filter

function out = ekf_sphere_coordiantes(measurement,UAV,t,P)

    persistent xhat
    persistent Phat

    z = measurement;  % measurements (from camera): eta-azimuth angle, xi-elevation angle
     
    % initialize Kalman filter
    if t<P.Ts,
        xhat = P.xhat0;
        Phat = P.Phat0;
    end

    % prediction step
    [xhat, Phat] = ekf_predict(xhat, Phat,UAV,P);
  
    % measurement update
    [xhat, Phat] = ekf_update(z, xhat, Phat, P);
    
    % measurement update
%     if mod(t,P.updateT)==0
%         [xhat, Phat] = ekf_update(z, xhat, Phat, P.R_ekf);
%     end
  
    out = [xhat; Phat(1,1); Phat(2,2); Phat(3,3);Phat(4,4)];   
end

function [xhat, Phat] = ekf_predict(xhat, Phat, UAV, P)


N = 5;
for i = 1:N
    
    kappa = xhat(1);
    eta   = xhat(2);
    xi    = xhat(3);
    
    f = [kappa^2*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi)); ...
        kappa*cos(UAV.theta)*sin(eta)/cos(xi)-UAV.psidot;...
        kappa  *(cos(UAV.theta)*cos(eta)*sin(xi)-sin(UAV.theta)*cos(xi))];
    
    A11 = 2*kappa*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi));
    A12 = -kappa^2*cos(UAV.theta)*sin(eta)*cos(xi);
    A13 = kappa^2*(-cos(UAV.theta)*cos(eta)*sin(xi)+sin(UAV.theta)*cos(xi));
    
    A21 = cos(UAV.theta)*sin(eta)/cos(xi);
    A22 = kappa*cos(UAV.theta)*cos(eta)/cos(xi);
    A23 = kappa*cos(UAV.theta)*sin(eta)/(cos(xi)^2)*sin(xi);
    
    A31 = cos(UAV.theta)*cos(eta)*sin(xi)-sin(UAV.theta)*cos(xi);
    A32 = -kappa*cos(UAV.theta)*sin(eta)*sin(xi);
    A33 =  kappa*(cos(UAV.theta)*cos(eta)*cos(xi)+sin(UAV.theta)*sin(xi));
    
    A = [A11 A12 A13;...
        A21 A22 A23;...
        A31 A32 A33];
    
    xhat = xhat+ P.Ts/N * f;
%     
%     xhat(1) = abs(xhat(1));
%     
%     if xhat(1)>P.UAV.V/P.dis_UAV_tegart_min
%         xhat(1) = P.UAV.V/P.dis_UAV_tegart_min;
% 
%     end
    
    Phat = Phat + P.Ts/N*(A*Phat + Phat*A' + P.Q);
    %         QQ = eye(4)*1; Phat = Phat + P.Ts/N*(A*Phat + Phat*A' +QQ);
    
end



end

%%
% ekf measurement update
%
function [xhat, Phat] = ekf_update(z, xhat, Phat, P)
C = [0 1 0;...
    0 0 1];
h_x = xhat(2:3);
K = Phat*C'/(C*Phat*C'+P.R);
Phat = (eye(3)-K*C)*Phat;
xhat = xhat + K*(z-h_x);

% xhat(1) = abs(xhat(1));

% if xhat(1)>P.UAV.V/P.dis_UAV_tegart_min
%     xhat(1) = P.UAV.V/P.dis_UAV_tegart_min;
% end
end