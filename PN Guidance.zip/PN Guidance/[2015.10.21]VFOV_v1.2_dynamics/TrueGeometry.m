function [ output ] = TrueGeometry( uu,P)
%TRUEGEOMETRY Summary of this function goes here
%   Detailed explanation goes here
output = uu(1:7);

end

