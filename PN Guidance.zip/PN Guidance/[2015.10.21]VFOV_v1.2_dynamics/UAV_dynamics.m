%% UAV_dynamics.m
%%
%% Generate 3D UAV motion based on a nonlinear kinematic model.
%%
%% Modified:
%%%    14/08/20 - Liang Sun
%%%    15/10/21 - Liang Sun
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sys,x0,str,ts] = UAV_dynamics(t,x,u,flag,P)
%
switch flag,
    
    %%%%%%%%%%%%%%%%%%
    % Initialization %
    %%%%%%%%%%%%%%%%%%
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes(P);
        
        %%%%%%%%%%%%%%%
        % Derivatives %
        %%%%%%%%%%%%%%%
    case 1,
        sys=mdlDerivatives(t,x,u,P);
        
        %%%%%%%%%%
        % Update %
        %%%%%%%%%%
    case 2,
        sys=mdlUpdate(t,x,u);
        
        %%%%%%%%%%%
        % Outputs %
        %%%%%%%%%%%
    case 3,
        sys=mdlOutputs(t,x,u,P);
        
        %%%%%%%%%%%%%%%%%%%%%%%
        % GetTimeOfNextVarHit %
        %%%%%%%%%%%%%%%%%%%%%%%
    case 4,
        sys=mdlGetTimeOfNextVarHit(t,x,u);
        
        %%%%%%%%%%%%%
        % Terminate %
        %%%%%%%%%%%%%
    case 9,
        sys=mdlTerminate(t,x,u);
        
        %%%%%%%%%%%%%%%%%%%%
        % Unexpected flags %
        %%%%%%%%%%%%%%%%%%%%
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
        
end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes(P)
%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = P.UAV.stateN*P.UAV.N;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = P.UAV.stateN*P.UAV.N;
sizes.NumInputs      = 4*P.UAV.N+3;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%

x0 = P.UAV.x0;

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,uu,P)
% process states
xdot = [];
wind = uu(end-2:end); % steady wind
wind_n = wind(1);
wind_e = wind(2);
wind(4:6,1) = 0; % gust

for i = 1:P.UAV.N
      NN = (i-1)*P.UAV.stateN;
      pn    = x(1+NN);    % north position (m)
      pe    = x(2+NN);    % east position (m)
      pd    = x(3+NN);    % position down (negative of altitude) (m)
      u     = x(4+NN);    % velocity along body x-axis (m/s)
      v     = x(5+NN);    % velocity along body y-axis (m/s)
      w     = x(6+NN);    % velocity along body z-axis (m/s)
      phi   = x(7+NN);   % roll angle (rad)
      theta = x(8+NN); % pitch angle  (rad)
      psi   = x(9+NN);   % yaw angle (rad)
      p     = x(10+NN);    % roll rate  (rad/s)
      q     = x(11+NN);    % pitch rate (rad/s)
      r     = x(12+NN);    % yaw rate (rad/s)
      
      state = x(1+NN:12+NN);
      % process inputs
      NN = (i-1)*4;
      delta = uu(1+NN:4+NN); 
%       delta = [0;0;0;0];
      out = forces_moments(state, delta, wind, P);
      
      Force  = out(1:3);
      fx     = Force(1);
      fy     = Force(2);
      fz     = Force(3);

      Torque = out(4:6);
      ell    = Torque(1);
      m      = Torque(2);
      n      = Torque(3);
      
%       Va     = out(7);
%       alpha  = out(8);
%       beta   = out(9);
%       w_n    = out(10);
%       w_e    = out(11);
%       w_d    = out(12);      
%       
      pndot = cos(theta)*cos(psi)*u...
          + (sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi))*v...
          + (cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi))*w;
      
      pedot = cos(theta)*sin(psi)*u...
          + (sin(phi)*sin(theta)*sin(psi)+cos(phi)*cos(psi))*v...
          + (cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi))*w;
      
      pddot = -sin(theta)*u...
          + sin(phi)*cos(theta)*v...
          + cos(phi)*cos(theta)*w;
      
      udot = r*v - q*w + (1/P.mass)*fx;
      
      vdot = p*w - r*u + (1/P.mass)*fy;
      
      wdot = q*u - p*v + (1/P.mass)*fz;
      
      phidot = p + sin(phi)*tan(theta)*q + cos(phi)*tan(theta)*r;
      
      thetadot = cos(phi)*q - sin(phi)*r;
      
      psidot = (sin(phi)/cos(theta))*q + (cos(phi)/cos(theta))*r;
      
      pdot = P.Gamma1*p*q - P.Gamma2*q*r + P.Gamma3*ell + P.Gamma4*n;
      
      qdot = P.Gamma5*p*r - P.Gamma4*(p*p-r*r) + (1/P.Jy)*m;
      
      rdot = P.Gamma7*p*q - P.Gamma1*q*r + P.Gamma4*ell + P.Gamma8*n;
      
      xdot = [xdot;...
      pndot; pedot; pddot;...
      udot; vdot; wdot;...
      phidot; thetadot; psidot;...
      pdot; qdot; rdot...
      ];
end



sys = xdot;

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u,P)

sys = x;

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate

%
%=============================================================================
% sat
% saturates the input between high and low
%=============================================================================
%
function out=sat(in, low, high)

if in < low,
    out = low;
elseif in > high,
    out = high;
else
    out = in;
end

% end sat
%
%=============================================================================
% lim_sat
% the integration variable is limited to be within a certain interval and
% the rate of increase is saturated
%=============================================================================
%
function state_dot = lim_sat(state, input, state_limit, rate_limit)

if ((state>=state_limit)&&(input>0))||((state<=-state_limit)&&( input<0))
    state_dot = 0;
else
    state_dot = sat(input, -rate_limit,rate_limit);
end

function out = forces_moments(x, delta, wind, P)

    % relabel the inputs
    pn      = x(1);
    pe      = x(2);
    pd      = x(3);
    u       = x(4);
    v       = x(5);
    w       = x(6);
    phi     = x(7);
    theta   = x(8);
    psi     = x(9);
    p       = x(10);
    q       = x(11);
    r       = x(12);
    delta_e = delta(1);
    delta_a = delta(2);
    delta_r = delta(3);
    delta_t = delta(4);
    w_ns    = wind(1); % steady wind - North
    w_es    = wind(2); % steady wind - East
    w_ds    = wind(3); % steady wind - Down
    u_wg    = wind(4); % gust along body x-axis
    v_wg    = wind(5); % gust along body y-axis    
    w_wg    = wind(6); % gust along body z-axis
    
    % convert steady inertial frame wind to the body frame
    % rotation from inertial frame to body frame
    R = [...
        1, 0, 0;...
        0, cos(phi), sin(phi);...
        0, -sin(phi), cos(phi)]*...
        [...
        cos(theta), 0, -sin(theta);...
        0, 1, 0;...
        sin(theta), 0, cos(theta)]*...
        [...
        cos(psi), sin(psi), 0;...
        -sin(psi), cos(psi), 0;...
        0, 0, 1];
    % compute wind vector in the body frame
    u_w = u_wg + R(1,:)*[w_ns; w_es; w_ds];
    v_w = v_wg + R(2,:)*[w_ns; w_es; w_ds];
    w_w = w_wg + R(3,:)*[w_ns; w_es; w_ds];
    % compute wind vector in the inertial frame
    w_n = w_ns + R(:,1)'*[u_wg; v_wg; w_wg];
    w_e = w_es + R(:,2)'*[u_wg; v_wg; w_wg];
    w_d = w_ds + R(:,3)'*[u_wg; v_wg; w_wg];
    
    % compute the velocity relative to the air mass
    ur      = u-u_w;
    vr      = v-v_w;
    wr      = w-w_w;
    
    % compute airspeed Va, angle-of-attack alpha, side-slip beta
    Va    = sqrt(ur^2 + vr^2 + wr^2);
    alpha = atan2(wr,ur);
    beta  = atan2(vr,sqrt(ur^2+wr^2));
    qbar = 0.5*P.rho*Va^2;
    ca    = cos(alpha);
    sa    = sin(alpha);
   
    % compute gravitaional forces
    Force(1) = -P.mass*P.g*sin(theta);
    Force(2) =  P.mass*P.g*cos(theta)*sin(phi);
    Force(3) =  P.mass*P.g*cos(theta)*cos(phi);
    
    % compute Lift and Drag forces
    tmp1 = exp(-P.M*(alpha-P.alpha0));
    tmp2 = exp(P.M*(alpha+P.alpha0));
    sigma = (1+tmp1+tmp2)/((1+tmp1)*(1+tmp2));
    CL = (1-sigma)*(P.C_L_0+P.C_L_alpha*alpha);
    AR = 2;
    e = .9;
    CD = P.C_D_0 + 1/pi/e/AR*(P.C_L_0+P.C_L_alpha*alpha)^2;
    if alpha>=0, 
        CL = CL + sigma*2*sa*sa*ca;
    else
        CL = CL - sigma*2*sa*sa*ca;
    end
    
    % compute aerodynamic forces
    Force(1) = Force(1) + qbar*P.S_wing*(-CD*ca + CL*sa);
    Force(1) = Force(1) + qbar*P.S_wing*(-P.C_D_q*ca + P.C_L_q*sa)*P.c*q/(2*Va);
    
    Force(2) = Force(2) + qbar*P.S_wing*(P.C_Y_0 + P.C_Y_beta*beta);
    Force(2) = Force(2) + qbar*P.S_wing*(P.C_Y_p*p + P.C_Y_r*r)*P.b/(2*Va);
    
    Force(3) = Force(3) + qbar*P.S_wing*(-CD*sa - CL*ca);
    Force(3) = Force(3) + qbar*P.S_wing*(-P.C_D_q*sa - P.C_L_q*ca)*P.c*q/(2*Va);
     
    % compute aerodynamic torques
    
    Torque(1) = qbar*P.S_wing*P.b*(P.C_ell_0 + P.C_ell_beta*beta);
    Torque(1) = Torque(1) + qbar*P.S_wing*P.b*(P.C_ell_p*p + P.C_ell_r*r)*P.b/(2*Va);

    Torque(2) = qbar*P.S_wing*P.c*(P.C_M_0 + P.C_M_alpha*alpha);
    Torque(2) = Torque(2) + qbar*P.S_wing*P.c*P.C_M_q*P.c*q/(2*Va);

    
    Torque(3) = qbar*P.S_wing*P.b*(P.C_n_0 + P.C_n_beta*beta);
    Torque(3) = Torque(3) + qbar*P.S_wing*P.b*(P.C_n_p*p + P.C_n_r*r)*P.b/(2*Va);

    % compute control forces
    Force(1) = Force(1) + qbar*P.S_wing*(-P.C_D_delta_e*ca+P.C_L_delta_e*sa)*delta_e;
    Force(2) = Force(2) + qbar*P.S_wing*(P.C_Y_delta_a*delta_a + P.C_Y_delta_r*delta_r);
    Force(3) = Force(3) + qbar*P.S_wing*(-P.C_D_delta_e*sa-P.C_L_delta_e*ca)*delta_e;
     
    % compute control torques
    Torque(1) = Torque(1) + qbar*P.S_wing*P.b*(P.C_ell_delta_a*delta_a + P.C_ell_delta_r*delta_r);
    Torque(2) = Torque(2) + qbar*P.S_wing*P.c*P.C_M_delta_e*delta_e;
    Torque(3) = Torque(3) + qbar*P.S_wing*P.b*(P.C_n_delta_a*delta_a + P.C_n_delta_r*delta_r);
    
    % compute propulsion forces
    motor_temp = P.k_motor^2*delta_t^2-Va^2;
    Force(1) = Force(1) + 0.5*P.rho*P.S_prop*P.C_prop*motor_temp;
    
    out = [Force'; Torque'; Va; alpha; beta; w_n; w_e; w_d];
