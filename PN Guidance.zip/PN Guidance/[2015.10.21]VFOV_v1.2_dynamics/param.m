%% param.m
%%%
%%% Parameters for the fixed wing UAV.
%%%
%% Modified:
%%%    14/08/20 - Liang Sun
%%%    15/10/21 - Liang Sun
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;
% close all;

% simulation edurance
P.simuT = 25; % second
P.record.flag = 0; % 1 -- record video; 0 -- do not record video

P.chi.k = 1;

% The number of UAVs.Must >=1.
P.UAV.N = 1;
P.UAV.stateN = 12;

% P.cam_fov = 40*pi/180;
P.az = 0;
P.el = 0;%-90*pi/180;

% sample rate of controller
P.samples_per_second = 50;
P.Ts = 1/P.samples_per_second;

% frame rate for camera (make it a multiple of sample rate)
P.frames_per_second = P.samples_per_second/10;
P.Tcam = 1/P.frames_per_second;
% number of control samples camera is delayed
P.cam_delay = round(P.samples_per_second/P.frames_per_second);

P.height_d = 100;  % height of UAV trajectory above ground (m)

P.orbit.center = [0;0];
P.orbit.dir = -1; % -1: counter-clockwise; 1: clockwise
P.orbit.radius = 500;
P.UAV.V = 25; % desired UAV velocity

% initial UAV states
% place all UAVs on a circle with evenly angular intervals
P.UAV.ini_location_interval = 2*pi/P.UAV.N;

for i=1:P.UAV.N
    P.UAV.x0((i-1)*12+1)  = P.orbit.radius*sin(P.UAV.ini_location_interval*(i-1));...          % pn:    north position (m)
    P.UAV.x0((i-1)*12+2)  = P.orbit.radius*cos(P.UAV.ini_location_interval*(i-1));...          % pe:    east position (m)
    P.UAV.x0((i-1)*12+3)  = -P.height_d;...          % altitude (m)
    P.UAV.x0((i-1)*12+4)  = P.UAV.V;...          % u:     velocity along body x-axis (m/s)
    P.UAV.x0((i-1)*12+5)  = 0;...          % v:     velocity along body y-axis (m/s)
    P.UAV.x0((i-1)*12+6)  = 0;...          % w:     velocity along body z-axis (m/s)
    P.UAV.x0((i-1)*12+7)  = 0*pi/180;...   % phi:   roll angle
    P.UAV.x0((i-1)*12+8)  = 0*pi/180;...   % theta: pitch angle
    P.UAV.x0((i-1)*12+9)  = -pi/2;...   % psi:   yaw angle
    P.UAV.x0((i-1)*12+10) = 0;...          % p:     roll rate
    P.UAV.x0((i-1)*12+11) = 0;...          % q:     pitch rate
    P.UAV.x0((i-1)*12+12) = 0;...          % r:     yaw rate
end

% mass and inertia
% inertia in kg-m^2
P.Jx = 0.114700;
P.Jy = 0.057600;
P.Jz = 0.171200;
P.Jxz = 0.001500;

% coefficients associated with inverse of J
P.Gamma  = P.Jx*P.Jz - P.Jxz^2;
P.Gamma1 = P.Jxz*(P.Jx - P.Jy + P.Jz)/P.Gamma;
P.Gamma2 = (P.Jz*(P.Jz-P.Jy) + P.Jxz^2)/P.Gamma;
P.Gamma3 = P.Jz/P.Gamma;
P.Gamma4 = P.Jxz/P.Gamma;
P.Gamma5 = (P.Jz-P.Jx)/P.Jy;
P.Gamma6 = P.Jxz/P.Jy;
P.Gamma7 = ((P.Jx-P.Jy)*P.Jx + P.Jxz^2)/P.Gamma;
P.Gamma8 = P.Jx/P.Gamma;

% gravity (m/s^2)
P.g = 9.806650;
% mass (kg)
P.mass = 1.56;

% aerodynamic coefficients
P.M             = 50;
P.epsilon       = 0.1592;
P.alpha0        = 0.4712;
P.rho           = 1.2682;
P.c             = 0.3302;
P.b             = 1.4224;
P.S_wing        = 0.2589;
P.S_prop        = 0.0314;
P.k_motor       = 20;
P.C_L_0         = 0.28;
P.C_L_alpha     = 3.45;
P.C_L_q         = 0.0;
P.C_L_delta_e   = -0.36;
P.C_D_0         = 0.03;
P.C_D_q         = 0.0;
P.C_D_delta_e   = 0.0;
P.C_M_0         = 0.0;
P.C_M_alpha     = -0.38;
P.C_M_q         = -3.6;
P.C_M_delta_e   = -0.5;
P.C_Y_0         = 0.0;
P.C_Y_beta      = -0.98;
P.C_Y_p         = -0.26;
P.C_Y_r         = 0.0;
P.C_Y_delta_a   = 0.0;
P.C_Y_delta_r   = -0.17;
P.C_ell_0       = 0.0;
P.C_ell_beta    = -0.12;
P.C_ell_p       = -0.26;
P.C_ell_r       = 0.14;
P.C_ell_delta_a = 0.08;
P.C_ell_delta_r = 0.105;
P.C_n_0         = 0.0;
P.C_n_beta      = 0.25;
P.C_n_p         = 0.022;
P.C_n_r         = -0.35;
P.C_n_delta_a   = 0.06;
P.C_n_delta_r   = -0.032;
P.C_prop        = 1;

P.L_wx = 1250;
P.L_wy = 1750;
P.L_wz = 1750;
P.sigma_wx = 1; 
P.sigma_wy = 1;
P.sigma_wz = 0.7;
% P.sigma_wx = 0; 
% P.sigma_wy = 0;
% P.sigma_wz = 0;
P.Va0 = P.UAV.V;

% compute trim conditions using 'mavsim_chap5_trim.mdl'
P.Va    = P.UAV.V;         % desired airspeed (m/s)
gamma = 0*pi/180;  % desired flight path angle (radians)
R     = 0; 

P.pitch_kp = -0.3;%-0.5477;
P.pitch_kd = -0.1394;
P.pitch_ki = 0;

P.course_kp = 0.5451;
P.course_kd = 0;
P.course_ki = 0.0875;

P.roll_kp = 2.1424;
P.roll_kd = 1.2341;
P.roll_ki = 0.1;

P.altitude_kp = 0.0656;
P.altitude_kd = 0;
P.altitude_ki = 0.0119;

P.sideslip_kp = 0.1;
P.sideslip_kd = -0.5;
P.sideslip_ki = 0;

P.airspeed_pitch_kp = -0.223;
P.airspeed_pitch_kd = 0;
P.airspeed_pitch_ki = -0.2534;

P.airspeed_throttle_kp = 7.0556;
P.airspeed_throttle_kd = 0;
P.airspeed_throttle_ki = 1.0550;

% altitude parameters and gains
P.altitude_take_off_zone = 10;
P.altitude_hold_zone = 10;

% propeller characteristics
P.kmotor_thrust = 5.45;  % F = 5.45*delta, where delta\in[0,1]
P.kmotor_torque = 0.0549; %

% parameters for guidance model
zeta_chi = .35;
wn_chi   = 0.85;
P.b_chi    = wn_chi^2;
P.b_chidot = 2*zeta_chi*wn_chi;

P.b_Va     = 8;

zeta_h       = .45;
wn_h         = .6;
P.b_h      = wn_h^2;
P.b_hdot   = 2*zeta_h*wn_h;
P.b_hnum   = 0;
P.b_roll   = 1;
P.b_phi    = 1/0.2;

% gravity (m/s^2)
P.g = 9.806650;
% mass (kg)
P.mass = 1.56;

P.wind_n = 0;
P.wind_e = 0;
P.wind_d = 0;

P.Va0 = P.UAV.V;

% compute trim conditions using 'mavsim_chap5_trim.mdl'
P.Va    = P.UAV.V;         % desired airspeed (m/s)
gamma = 0*pi/180;  % desired flight path angle (radians)
R     = 0; 

% dirty derivative parameter
P.tau = 1/5;
P.wind_n = 0;
P.wind_e = 0;
P.wind_d = 0;

% camera parameters
P.cam_pix = 480;         % size of (square) pixel array
P.cam_fov = 60*(pi/180); % field of view of camera
P.f = (P.cam_pix/2)/tan(P.cam_fov/2); % focal range
P.eps_s_d = 36;  % desired pixel size in image

% target parameters
P.target_size = 10;  % initial location of target
% initial conditions of the target

% waypoints for target to follow
t = 0:100;
P.target.V = 10;
P.target.Home = [100;0];
P.waypoint.mag = 100;
P.waypoint.n = P.target.V * t';
P.waypoint.e = P.waypoint.mag*sin(P.waypoint.n*2*pi/120);
P.target_waypoints = repmat(P.target.Home',length(P.waypoint.n),1) + [P.waypoint.n,P.waypoint.e];
% commanded speed of target
P.target_speed = P.target.V;

P.target0 = [...
    P.target.Home(1);...  % initial North position
    P.target.Home(2);...  % initial East position
    0;...  % initial Down position
    0;...  % initial forward speed
    0;...  % initial heading
    ];

% control gains for feedback control;
P.ctrlGain.k1 = 1;
P.ctrlGain.k2 = 1;

P.k_orbit = 0.03;  % 0.01 proportional gain for tracking oribits
P.k_roll = 1;          % roll attitude hold proportional gain

P.UAV.phibar = 45*(pi/180); % (rad) roll angle constraint
P.UAV.phidotbar = 100*(pi/180);       % 100(rad/sec) roll rate constraint

P.accele_bar = 0.5;

% display scale

square_size = 550;

P.xmax = square_size;
P.xmin = -square_size;
P.ymax = square_size;
P.ymin = -square_size;
P.zmax = 150;
P.zmin = 0;

%% parameters for path planning
P.sensingRange = 200; % meter
P.theta_bar = 35*pi/180; % deg
P.path.aa = 3*sin(P.theta_bar+P.cam_fov/2)*sin(P.theta_bar)/sin(P.cam_fov/2);
P.path.bb = sqrt(P.path.aa^2 + (P.path.aa*cot(pi-P.theta_bar-P.cam_fov/2)+6)^2);
sigma = P.sensingRange/P.path.bb;
P.path.cc = P.path.aa*cot(P.theta_bar);
P.h_desired = P.path.aa*sigma;
P.circle_radius = P.path.cc*sigma;

%% params for EKF
dis0 = 100; % original distance between target and UAV, meter
P.xhat0 = [P.Va/dis0;0.5;-0.5];
P.Phat0 = eye(3);
P.Q = diag([0.0001,1*pi/180,1*pi/180]);
P.R = diag([5*pi/180,5*pi/180]);

%% control gain
P.k_theta = 10;
P.k_phi   = 1;
P.dis_UAV_tegart_min = 10;

%% bias parameters for IMU/sensors
P.gyro_x_bias  = .025;
P.gyro_y_bias  = .025;
P.gyro_z_bias  = .025;
P.accel_x_bias = .025;
P.accel_y_bias = .025;
P.accel_z_bias = .025;

%% noise parameters for IMU/sensors
P.rho = 1.2682;

P.gravity= 9.8;

% sensor parameters
P.sigma_gyro = 0.13*pi/180; % standard deviation of gyros in rad/sec
P.bias_gyro_x = 0.1*pi/180*rand; % bias on x_gyro
P.bias_gyro_y = 0.1*pi/180*rand; % bias on y_gyro
P.bias_gyro_z = 0.1*pi/180*rand; % bias on z_gyro
P.sigma_accel = 0.0025*9.8; % standard deviation of accelerometers in m/s^2
P.sigma_static_pres = 0.01*1000; % standard deviation of static pressure sensor in Pascals
P.sigma_diff_pres = 0.002*1000;  % standard deviation of diff pressure sensor in Pascals

% set sensor noise to zero to test KF with no noise (should work great)
% P.sigma_gyro = 0.0; % standard deviation of gyros in rad/sec
% P.bias_gyro_x = 0.0; % bias on x_gyro
% P.bias_gyro_y = 0.0; % bias on y_gyro
% P.bias_gyro_z = 0.0; % bias on z_gyro
% P.sigma_accel = 0.0; % standard deviation of accelerometers in m/s^2
% P.sigma_static_pres = 0.0; % standard deviation of static pressure sensor in Pascals
% P.sigma_diff_pres = 0.0;  % standard deviation of diff pressure sensor in Pascals


% GPS parameters
P.Ts_gps = 1; % sample rate of GPS in s
P.beta_gps = 1/1100; % 1/s
P.sigma_n_gps = 0.21;
P.sigma_e_gps = 0.21; 
P.sigma_h_gps = 0.40;
P.sigma_Vg_gps = 0.05;
P.sigma_course_gps = P.sigma_Vg_gps/P.Va;

% GPS parameters
P.Ts_gps = 1; % sample rate of GPS in s
P.beta_gps = 1/1100; % 1/s
P.sigma_n_gps = 0.21;
P.sigma_e_gps = 0.21; 
P.sigma_h_gps = 0.40;
P.sigma_Vg_gps = 0.05;
P.sigma_course_gps = P.sigma_Vg_gps/P.Va;
