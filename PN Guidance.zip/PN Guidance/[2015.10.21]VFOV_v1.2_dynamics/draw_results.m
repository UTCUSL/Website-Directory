param

% %%
T = P.simuT;
% step = P.Tcam;
% 

% dotn = T/step+1;

markerSize = 15;

% --------------------------------------------------------------------------------------------------------
%% Draw the desired trajectory of the mothership 222
% clear all
camera = load('camera.mat');
uav  = load('UAV.mat');
eta_xi = load('eta_xi.mat');
phi_thetadot = load('phi_thetadot.mat');
target = load('target.mat');
% define the line width
linw = 3;
%% 3D view system trajectories
figure(11)
clf(11)

plot(camera.ans(2,1), -camera.ans(3,1),'kx','LineWidth',3,...
     'MarkerSize',markerSize,...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor',[0.5,0.5,0.5])   %T/step
hold on
plot(camera.ans(2,end), -camera.ans(3,end),'bo','LineWidth',3,...
     'MarkerSize',markerSize,...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor',[0.5,0.5,0.5]) 
plot(camera.ans(2,1:end), -camera.ans(3,1:end),'r','LineWidth',1)   %T/step
set(gca,'FontSize',12)
axis([-P.cam_pix/2,P.cam_pix/2,-P.cam_pix/2,P.cam_pix/2])
legend('Starting','Ending')

hold on
title('Target trajectory in camera','fontsize',18)
xlabel({'x, pixel'},'fontsize',16)
ylabel('y, pixel','fontsize',16)



%%
 figure(12)
clf(12)
set(gca,'FontSize',12)
t = camera.ans(1,:);

subplot(3,1,1)
plot(t,camera.ans(2,1:end),'k','LineWidth',linw)   %T/step
title('Target motion in camera view (in pixel)','fontsize',18)
ylabel('\epsilon_x','fontsize',16)
grid on

subplot(3,1,2)
plot(t,camera.ans(3,1:end),'LineWidth',linw)   %T/step
ylabel('\epsilon_y','fontsize',16)
grid on

subplot(3,1,3)
plot(t,sqrt(camera.ans(2,1:end).^2+camera.ans(3,1:end).^2),'LineWidth',linw)   %T/step
% hold on
% Draw the actural position of the mothership in x-y plane
% 
% plot(temp(2,1:end), temp(1,1:end),'--k','LineWidth',linw)
% axis([-250 350 -250 250])
grid on
xlabel({'t, s'},'fontsize',16)
ylabel('Dis2center','fontsize',16)

%%

 figure(13)
clf(13)
set(gca,'FontSize',12)
t = 0:P.Ts:(T);

subplot(2,1,1)
plot(t,phi_thetadot.ans(2,1:end),'k','LineWidth',linw)   %T/step
title('UAV Inputs','fontsize',18)
ylabel('\phi','fontsize',16)
grid on

subplot(2,1,2)
plot(t,phi_thetadot.ans(3,1:end),'LineWidth',linw)   %T/step
xlabel({'t, s'},'fontsize',16)
ylabel('\theta rate','fontsize',16)
grid on

%%
 figure(14)
clf(14)
set(gca,'FontSize',12)
t = 0:P.Ts:(T);


plot3(target.ans(3,1:end),target.ans(2,1:end),zeros(size(target.ans(3,1:end))),'r','LineWidth',linw)   %T/step
hold on

plot3(uav.ans(3,1:end),uav.ans(2,1:end),-uav.ans(4,1:end),'LineWidth',linw)  

hold on
plot3(uav.ans(3,1),uav.ans(2,1),-uav.ans(4,1),'kx','LineWidth',linw,...
        'MarkerSize',markerSize,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[0.5,0.5,0.5])   
hold on
plot3(target.ans(3,1),target.ans(2,1),zeros(size(target.ans(3,1))),'kx','LineWidth',linw,...
        'MarkerSize',markerSize,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[0.5,0.5,0.5])   %T/step


title('Target and UAV Trajectories','fontsize',18)

xlabel('East, m','fontsize',16)
ylabel('North, m','fontsize',16)
zlabel('Altitude, m','fontsize',16)

legend('Target','UAV','Starting')

grid on

%%
 figure(15)
clf(15)
set(gca,'FontSize',12)
% t = 0:P.Ts:(T);
t = uav.ans(1,:);
hdot = uav.ans(end,1:end);
theta = asin(hdot/P.Va);

err = 180/pi*(theta - eta_xi.ans(3,1:end));
subplot(2,1,1)

plot(t,180/pi*eta_xi.ans(2,1:length(t)),'LineWidth',linw)   %T/step
title('Tracking errors','fontsize',18)
ylabel('\eta,deg','fontsize',16)
grid on

subplot(2,1,2)

plot(t,err(1:length(t)),'k','LineWidth',linw)   %T/step

xlabel({'t, s'},'fontsize',16)
ylabel('\gamma-\xi,deg ','fontsize',16)



grid on

% zlabel('Altitude, m','fontsize',16)
% legend('Desired','Actual')


% legend('Desired','Actual')
% 
% % Draw the actural position of the mothership in x-y plane
% intv = 12;
% for i = 1:floor(length(xreal.ans(3,1:end))/intv)
%     temp(1:3,i) = xreal.ans(2:4,intv*i);
% end
% plot3(temp(2,1:end), temp(1,1:end),-temp(3,1:end),'--k','LineWidth',linw)
% axis([-250 350 -250 250 150 220])
% grid on
% view([45 20])
% title('3-D view of system trajectory','fontsize',16)
% xlabel({'East, m'},'fontsize',16)
% ylabel('North, m','fontsize',16)
% zlabel('Altitude, m','fontsize',16)
% legend('Desired','Actual')
% 
% %% top-down view of the system 
% figure(12)
% clf(12)
% 
% plot(p_m_d.ans(3,1:end), p_m_d.ans(2,1:end),'r','LineWidth',linw)   %T/step
% set(gca,'FontSize',12)
% hold on
% % Draw the actural position of the mothership in x-y plane
% intv = 12;
% for i = 1:floor(length(xreal.ans(3,1:end))/intv)
%     temp(1:3,i) = xreal.ans(2:4,intv*i);
% end
% plot(temp(2,1:end), temp(1,1:end),'--k','LineWidth',linw)
% axis([-250 350 -250 250])
% grid on
% title('Top-down view of system trajectory','fontsize',16)
% xlabel({'East, m'},'fontsize',16)
% ylabel('North, m','fontsize',16)
% % zlabel('Altitude, m','fontsize',16)
% legend('Desired','Actual')
% 
% %% tracking error
% 
% figure(13)
% clf(13)
% set(gca,'FontSize',12)
% 
% subplot(3,1,1)
% plot(t,p_m_d.ans(3,1:end)-xreal.ans(3,1:end),'k','LineWidth',linw)   %T/step
% title('UAS trajectory tracking error','fontsize',16)
% ylabel('North, m','fontsize',16)
% grid on
% 
% subplot(3,1,2)
% plot(t,p_m_d.ans(2,1:end)-xreal.ans(2,1:end),'LineWidth',linw)   %T/step
% ylabel('East, m','fontsize',16)
% grid on
% 
% subplot(3,1,3)
% plot(t,p_m_d.ans(4,1:end)-xreal.ans(4,1:end),'LineWidth',linw)   %T/step
% % hold on
% % Draw the actural position of the mothership in x-y plane
% % 
% % plot(temp(2,1:end), temp(1,1:end),'--k','LineWidth',linw)
% % axis([-250 350 -250 250])
% grid on
% xlabel({'t, s'},'fontsize',16)
% ylabel('Altitude, m','fontsize',16)
% % zlabel('Altitude, m','fontsize',16)
% % legend('Desired','Actual')
% 
% 
% %% Va,psi,gam, phi
% % linw = 2;
% 
% figure(14)
% clf(14)
% 
% subplot(4,1,1)
% plot(t,xreal.ans(5,1:end),'LineWidth',linw)   %T/step
% axis([0 150 0 30])
% grid on
% title('Variable Evolutions','fontsize',16)
% ylabel('V_a, m/s','fontsize',16)
% 
% subplot(4,1,2)
% plot(t,180/pi*xreal.ans(6,1:end),'LineWidth',linw)   %T/step
% ylabel('\psi, deg','fontsize',16)
% grid on
% 
% subplot(4,1,3)
% plot(t,180/pi*xreal.ans(8,1:end),'LineWidth',linw)   %T/step
% axis([0 150 -10 20])
% grid on
% ylabel({'\gamma_a, deg'},'fontsize',16)
% 
% subplot(4,1,4)
% plot(t,180/pi*xreal.ans(7,1:end),'LineWidth',linw)   %T/step
% axis([0 150 -40 50])
% grid on
% xlabel({'t, s'},'fontsize',16)
% ylabel('{\phi}, deg','fontsize',16)
% 
% set(gca,'FontSize',12)
% 
% %% tracking error of xi and xihat
% 
% figure(15)
% clf(15)
% set(gca,'FontSize',12)
% 
% subplot(4,1,1)
% plot(t,xhat.ans(5,1:end)-xreal.ans(5,1:end),'LineWidth',linw)   %T/step
% title('Variable Errors','fontsize',16)
% ylabel('E_{V_a}, m','fontsize',16)
% axis([0 150 -10 5])
% grid on
% 
% subplot(4,1,2)
% plot(t,xhat.ans(6,1:end)-xreal.ans(6,1:end),'LineWidth',linw)   %T/step
% ylabel('E_\psi, m','fontsize',16)
% axis([0 150 -1 2])
% grid on
% 
% subplot(4,1,3)
% plot(t,xhat.ans(8,1:end)-xreal.ans(8,1:end),'LineWidth',linw)   %T/step
% axis([0 150 -.1 .2])
% grid on
% ylabel('E_{\gamma_a}, m','fontsize',16)
% 
% subplot(4,1,4)
% plot(t,xhat.ans(7,1:end)-xreal.ans(7,1:end),'LineWidth',linw)   %T/step
% axis([0 150 -2 1])
% grid on
% xlabel({'t, s'},'fontsize',16)
% ylabel('E_\phi, m','fontsize',16)
% 
% %% Distance err
% figure(16),clf
% set(gca,'FontSize',12)
% err = sqrt((p_m_d.ans(2,1:end)-xreal.ans(2,1:end)).^2 ...
%           +(p_m_d.ans(3,1:end)-xreal.ans(3,1:end)).^2 ...
%           +(p_m_d.ans(4,1:end)-xreal.ans(4,1:end)).^2);
% plot(t,err,'LineWidth',linw), hold on
% rho = min([P.comSys.L+P.real.k1,P.real.k2,P.real.k3]);
% UBound = P.rand_mag*sqrt(3)/(rho);
% plot(t,ones(size(t))*UBound,'--','LineWidth',linw*2)
% axis([0 150 0 UBound+50])
% grid on
% title('Tracking error in distance','fontsize',16)
% xlabel({'Time, s'},'fontsize',16)
% ylabel('Tracking error, m','fontsize',16)
% 
% legend('Trk Err','UBound')
% 
% 
% % zlabel('Altitude, m','fontsize',16)
% % legend('Desired','Actual')
% 
% % zlabel('Altitude, m','fontsize',16)
% % legend('Desired','Actual')
% 
% 
% % %% Draw the actural position of the mothership in x-z plane
% % figure(17),clf(17)
% % plot(mothership_n.ans(2,1:dotn), mothership_d.ans(2,1:dotn),'k--','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % grid on
% % title('Side view of mothership trajectory','fontsize',16)
% % xlabel({'North(m)'},'fontsize',16)
% % ylabel('Altitude (m)','fontsize',16)
% % % legend('Desired trajectory','Actual trajectory','fontsize',16)
% % 
% % %% Draw the error in pn
% % figure(12)
% % clf(12)
% % h1 = subplot(3,1,1);
% % % axes('FontSize',15)
% % plot(t(1:dotn),mothership_n.ans(2,1:dotn)-mothership_p_d.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(mothership_n.ans(2,1:dotn)-mothership_p_d.ans(2,1:dotn)))
% % grid on
% % title('Mothership error in North','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % 
% % % axis([0 dotn -100 100])
% % % Draw the error in pe
% % subplot(3,1,2)
% % plot(t(1:dotn),mothership_e.ans(2,1:dotn)-mothership_p_d.ans(3,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(mothership_e.ans(2,1:dotn)-mothership_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % title('Mothership error in East','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % 
% % % axis equal
% % grid on
% % 
% % % Draw the error in pd
% % subplot(3,1,3)
% % plot(t(1:dotn),mothership_d.ans(2,1:dotn)+mothership_p_d.ans(4,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(mothership_e.ans(2,1:dotn)-mothership_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % title('Mothership error in Altitude','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % 
% % % axis equal
% % grid on
% % % xlabel('North (meter)');
% % % ylabel('East (meter)');
% % % zlabel('Height (meter)');
% % 
% % 
% % 
% % %% Draw the desired trajectory of the drogue 222
% % 
% % figure(13)
% % clf(13)
% % drogue_p_d = P.drogue.pd;
% % drogue_n   = load('drogue_x.mat');
% % drogue_e   = load('drogue_y.mat');
% % drogue_d   = load('drogue_h.mat');
% % % dotn =180/P.ts;
% % 
% % plot(drogue_p_d(2,1:dotn), drogue_p_d(1,1:dotn),'r','LineWidth',2) %T/step
% % set(gca,'FontSize',12)
% % % plot(drogue_p_d.ans(3,1:end), drogue_p_d.ans(2,1:end))   %T/step
% % 
% % hold on
% % % Draw the actural position of the drogue in x-y plane
% % plot(drogue_e.ans(2,1:dotn), drogue_n.ans(2,1:dotn),'k--','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % grid on
% % title('Top-down view of Drogue trajectory','fontsize',16)
% % xlabel('East (m)','fontsize',16)
% % ylabel('North (m)','fontsize',16)
% % legend('Desired trajectory','Actual trajectory')
% % %% Draw the actural position of the drogue in x-z plane
% % figure(18),clf(18)
% % 
% % plot(drogue_e.ans(2,1:dotn), drogue_d.ans(2,1:dotn),'k--','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % grid on
% % title('Side view of drogue trajectory','fontsize',16)
% % xlabel('East (m)','fontsize',16)
% % ylabel('Altitude (m)','fontsize',16)
% % % legend('Desired trajectory','Actual trajectory','fontsize',16)
% % 
% % 
% % %% Draw the error in pn
% % figure(14)
% % clf(14)
% % subplot(3,1,1)
% % plot(t(1:dotn),drogue_n.ans(2,1:dotn)-drogue_p_d(1,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_n.ans(2,1:dotn)-drogue_p_d.ans(2,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % title('Drogue position error in North','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % 
% % 
% % % Draw the error in pe
% % subplot(3,1,2)
% % plot(t(1:dotn),drogue_e.ans(2,1:dotn)-drogue_p_d(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % title('Drogue position error in East','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % % axis equal
% % grid on
% % 
% % % Draw the error in pd
% % subplot(3,1,3)
% % % plot(t(1:dotn),drogue_d.ans(2,1:dotn)+drogue_p_d.ans(4,1:dotn))
% % 
% % plot(t(1:dotn),drogue_d.ans(2,1:dotn)+ P.drogue.d_c * ones(1,dotn),'k','LineWidth',2)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % title('Drogue position error in Altitude','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % % axis equal
% % grid on
% % 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % %% Draw the mothership roll and pitch
% % mothership_roll = load('mothership_roll.mat');
% % figure (15), clf
% % 
% % subplot(4,1,1)
% % plot(t(1:dotn),mothership_roll.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % % title('Drogue position error in Height')
% % xlabel('Time(s)','fontsize',16)
% % ylabel('\phi (deg)','fontsize',16)
% % % axis equal
% % grid on
% % 
% % mothership_pitch = load('mothership_pitch.mat');
% % subplot(4,1,2)
% % plot(t(1:dotn),mothership_pitch.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % % title('Drogue position error in Height')
% % xlabel('Time(s)','fontsize',16)
% % ylabel('\gamma_a (deg)','fontsize',16)
% % % axis equal
% % grid on
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % %% Draw the mothership tau and load factor
% % mothership_tau = load('mothership_tau.mat');
% % % figure (16),clf
% % subplot(4,1,3)
% % plot(t(1:dotn),mothership_tau.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % % title('Drogue position error in Height')
% % xlabel('Time(s)','fontsize',16)
% % ylabel('T (N)','fontsize',16)
% % % axis equal
% % grid on
% % 
% % mothership_loadf = load('mothership_loadf.mat');
% % subplot(4,1,4)
% % plot(t(1:dotn),mothership_loadf.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % 
% % % plot(t(1:dotn),abs(drogue_e.ans(2,1:dotn)-drogue_p_d.ans(3,1:dotn)))
% % % axis([0 dotn -0.1 0.1])
% % grid on
% % % title('Drogue position error in Height')
% % xlabel('Time(s)','fontsize',16)
% % ylabel('n','fontsize',16)
% % % axis equal
% % grid on
% % 
% % %% Draw the 3D traj for both mothp and drg
% % 
% % figure(19),clf
% % plot3(mothership_n.ans(2,1:dotn),mothership_e.ans(2,1:dotn),mothership_d.ans(2,1:dotn),'k','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % 
% % hold on, grid on
% % plot3(drogue_n.ans(2,1:dotn),drogue_e.ans(2,1:dotn),drogue_d.ans(2,1:dotn),'r','LineWidth',1.5)
% % set(gca,'FontSize',12)
% % 
% % title('Trajectory in 3D','fontsize',16)
% % xlabel('East(m)','fontsize',16)
% % ylabel('Norht(m)','fontsize',16)
% % zlabel('Altitude(m)','fontsize',16)
% % 
% % %% Draw the norm(Err_m) with ultimate bound--------------------------------------------------------------------------------------------------------
% % 
% % err_m_n = mothership_n.ans(2,1:dotn)-mothership_p_d.ans(2,1:dotn);
% % err_m_e = mothership_e.ans(2,1:dotn)-mothership_p_d.ans(3,1:dotn);
% % err_m_d = mothership_d.ans(2,1:dotn)+mothership_p_d.ans(4,1:dotn);
% % for i =1:length(err_m_n)
% %     err_m (i) = norm([err_m_n(i);err_m_e(i);err_m_d(i)]);
% % end
% % %%
% % figure(20)
% % clf(20)
% % plot(t(1:dotn),err_m(1:dotn),'k','LineWidth',1.5), hold on
% % set(gca,'FontSize',12)
% % 
% % ind = 1:dotn*P.ts;
% % plot(ind,P.mothership.UB*ones(1,dotn*P.ts),'--k','LineWidth',2), hold on
% % legend('Mothership error','Ultimate bound')
% % % grid on
% % title('Mothership error magnitude vs time','fontsize',16)
% % xlabel('Time(s)','fontsize',16)
% % ylabel('Error(m)','fontsize',16)
% % axis([0 dotn*P.ts 0 3.5])
% % 
% % % legend('Motherhip trajectory','Drogue trajectory','fontsize',16)
% % 
% % % %% draw in seperate view
% % % subplot(2,1,1)
% % % plot(t,drogue_pos_y.ans(2,1:8000))
% % % xlabel('Time (second)');
% % % ylabel('East (meter)');
% % % grid on
% % % 
% % % subplot(2,1,2)
% % % plot(t,drogue_pos_x.ans(2,1:8000))
% % % xlabel('Time (second)');
% % % ylabel('North (meter)');
% % % grid on
% % % 
% % % %% draw in 3-D view
% % % 
% % % figure(12)
% % % plot(drogue_pos_y.ans(2,1:4000), drogue_pos_x.ans(2,1:4000))
% % % plot3(t,drogue_pos_y.ans(2,1:4000), drogue_pos_x.ans(2,1:4000))
% % % title('')
% % % xlabel('Time (second)');
% % % ylabel('East (meter)');
% % % zlabel('North (meter)');
% % grid on