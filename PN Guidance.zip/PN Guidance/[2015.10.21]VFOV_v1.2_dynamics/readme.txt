1. Load "param.m"
2. Open "FixedWingUAVSim.mdl" and run the simulation.
3. All parameters are stored and should be modified in "param.m".