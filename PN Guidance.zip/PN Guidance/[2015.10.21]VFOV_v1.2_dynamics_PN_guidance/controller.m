%% controller.m
%%
%% Calculate control inputs to UAV_dynamics for target tracking mission.
%%
%% Modified:
%%    14/08/20 - Liang Sun
%%%    15/10/21 - Liang Sun
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function delta = controller(uu,P)
%
persistent target_chi_dot_k1 target_chi_ddot
% define persistent variable for state of altitude state machine
persistent altitude_state;
persistent initialize_integrator;

% initialize persistent variables at beginning of simulation
t = uu(1);
% NN = 1;
% camera.qx   = uu(1+NN);
% camera.qy   = uu(2+NN);
% camera.target_size = uu(3+NN);
% camera.target_chi  = uu(4+NN);

NN = 1+7+P.UAV.N*P.UAV.stateN;
target.pn      = uu(1+NN);    % north position (m)
target.pe      = uu(2+NN);    % east position (m)
target.pd      = uu(3+NN);    % position down (negative of altitude) (m)
target.V      = uu(4+NN);    % linear speed
target.chi    = uu(5+NN);    % heading (rad)
target.Vdot   = uu(6+NN);    % Vdot
target.chidot = uu(7+NN);    % chidot

NN = 1;
% target.kappa  = uu(1+NN);    % north position (m)
% % target.kappa = 0;
% target.eta    = uu(2+NN);    % east position (m)
% target.xi     = uu(3+NN);    % position down (negative of altitude) (m)
% target.V      = uu(4+NN);    % linear speed
% target.chi    = uu(5+NN);    % heading (rad)
% target.Vdot   = uu(6+NN);    % Vdot
% target.chidot = uu(7+NN);    % chidot

target.sigma = 30+2*sin(t);

% differentiate chidot
if t<P.Ts
    target_chi_ddot=0;
    target_chi_dot_k1 = target.chidot;
else
    
    target_chi_ddot = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*target_chi_ddot...
        + (2/(2*P.tau+P.Ts))*(target.chidot - target_chi_dot_k1);
    target_chi_dot_k1 = target.chidot;
end
% target.chi_ddot = target_chi_ddot;
target.chi_ddot = 0;

%% ===================================================================================================
% UAV states
delta = []; % output of the controller
if t<P.Ts
    err_old = zeros(3,P.UAV.N);
    altitude_state = zeros(P.UAV.N,1);
    initialize_integrator = zeros(P.UAV.N,1);    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% cmd = []; % output of the controller

for i=1:P.UAV.N

    NN = 1+7+(i-1)*P.UAV.stateN;
    UAV.pn     = uu(1+NN);    % north position (m)
    UAV.pe     = uu(2+NN);    % east position (m)
    UAV.pd     = uu(3+NN);    % position down (negative of altitude) (m)
    UAV.u      = uu(4+NN);    % velocity along body x-axis (m/s)
    UAV.v      = uu(5+NN);    % velocity along body y-axis (m/s)
    UAV.w      = uu(6+NN);    % velocity along body z-axis (m/s)
    UAV.phi    = uu(7+NN);   % roll angle (rad)
    UAV.theta  = uu(8+NN); % pitch angle  (rad)
    UAV.psi    = uu(9+NN);   % yaw angle (rad)
    UAV.p      = uu(10+NN);    % roll rate  (rad/s)
    UAV.q      = uu(11+NN);    % pitch rate (rad/s)
    UAV.r      = uu(12+NN);    % yaw rate (rad/s)
    
    UAV.h = -UAV.pd;
    
    wn = 0;
    we = 0;
    
    % airspeed projected on the ground
    Va_g = sqrt(UAV.u^2 + UAV.v^2);
    UAV.Va = sqrt(UAV.u^2 + UAV.v^2 + UAV.w^2);
    VN = Va_g*cos(UAV.psi)+wn;
    VE = Va_g*sin(UAV.psi)+we;
    UAV.Vg     = sqrt(VN^2 + VE^2);
    UAV.chi = atan2(VE, VN);
    UAV.gam = atan2(UAV.w, UAV.Vg);
    VD = -UAV.Va*sin(UAV.gam);
    alpha = atan2(UAV.w, UAV.u);

    
    %% PN guidance law
    p_t = [target.pn;target.pe;target.pd];
    p_u = [UAV.pn;UAV.pe;UAV.pd];
    p_r = p_t - p_u;
    
    unit_p_r = p_r/norm(p_r);
    
    v_t = target.V*[cos(target.chi);sin(target.chi);0];
    v_u = [VN;VE;VD];%[UAV.u;UAV.v;UAV.w];
    v_r = v_t - v_u;
    unit_v_r = v_r/norm(v_r);
    unit_v_u = v_u/norm(v_u);
    
%     Omega = cross(unit_p_r,unit_v_r);
    Omega = cross(unit_p_r,unit_v_r);
%     Omega = cross(unit_p_r,v_r)/norm(p_r);
    Omega_2 = cross(unit_p_r,unit_v_u);
    
%     pd_ddot = -P.PNGuidance.gain * norm(v_r)*cross(p_r,Omega)/norm(p_r); 
%     pd_ddot =  cross(unit_v_u,Omega_2);
    pd_ddot =  3*cross(v_r,Omega);
%     pd_ddot =  3*norm(v_r)*cross(unit_p_r,Omega);
%     pd_ddot =- 4 * norm(v_r) * cross(unit_v_r,Omega);
%     pd_ddot = P.PNGuidance.gain *cross(v_r,Omega);
    
    M = [cos(UAV.gam)*cos(UAV.chi) -UAV.Vg *sin(UAV.gam)*cos(UAV.chi) -UAV.Vg *cos(UAV.gam)*sin(UAV.chi);...
         cos(UAV.gam)*sin(UAV.chi) -UAV.Vg *sin(UAV.gam)*sin(UAV.chi)  UAV.Vg *cos(UAV.gam)*cos(UAV.chi);...
         -sin(UAV.gam)             -UAV.Vg *cos(UAV.gam)           0];
    
    temp = (M\pd_ddot);
    
%     desired_temp = P.PNGuidance.gain * temp;
    desired_temp = temp;
%     desired_temp = temp;
%     Vg_dot_d = desired_temp(1);
    Va_c = P.UAV.V;    
    gam_dot_d = desired_temp(2);
    gam_c = UAV.theta + P.Ts* gam_dot_d;
    theta_c = gam_c;%+alpha;
%     theta_c = UAV.theta + P.Ts* gam_dot_d;
    h_c = UAV.h+ P.Ts* UAV.Vg*sin(gam_c);
    
    chi_dot_d = desired_temp(3);
    phi_c = atan(chi_dot_d*UAV.Va/P.g);
    aaaaa = 1;
%     chi_c = UAV.chi + P.Ts*chi_dot_d;
%     chi_c = -10*pi/180;
    
    %% Sliding-mode Guidance law
%     epsilon = 0.5;
%     epsilon_theta = 0.1;
%     B0 = 0.05;
%     B0_theta = 5;
%     % sliding mode controller
%     kappa_max = UAV.Va/30;
%     theta_dot = -(kappa_max*abs(cos(UAV.theta)*cos(target.eta)*sin(target.xi)-sin(UAV.theta)*cos(target.xi))+B0_theta) ...
%                *satSgn((UAV.theta-target.xi)/epsilon_theta);
%             
%     theta_c = UAV.theta+P.Ts*theta_dot;
%     
%     h_c = UAV.h+UAV.Va*sin(theta_c);
% %     h_c = P.height_d + 5*sin(t);
%     Va_c = P.UAV.V;
%      
% %     phi_c = trackOrbit(UAV, P.orbit.center, P.orbit.radius, P.orbit.dir, P, t);
% %     phi_c = trackTarget(UAV,target,P,t);
%     
%     psidot_c = (kappa_max*abs(cos(UAV.theta)*cos(target.eta)/cos(target.xi))+B0) *satSgn((target.eta)/epsilon);
%     phi_c = atan(psidot_c*UAV.Va/P.g);   
%     chi_c = UAV.chi + P.Ts*psidot_c;
%     chi_c = -10*pi/180;
%     h_c = P.height_d;
%     Va_c = P.UAV.V;
    
%% implement autopilot modes 
    if t==0,
        % assume no rudder, therefore set delta_r=0
        delta_r = 0;%coordinated_turn_hold(beta, 1, P);
        % use commanded roll angle to regulate heading
%         phi_c   = course_hold(chi_c, UAV.chi, UAV.r, 1, P);
%             phi_c = trackOrbit(UAV, P.orbit.center, P.orbit.radius, P.orbit.dir, P, t);

        % use aileron to regulate roll angle
        delta_a = roll_hold(phi_c, UAV.phi, UAV.p, 1, P);     

    else
        delta_r = 0;%coordinated_turn_hold(beta, 0, P);
%         phi_c   = course_hold(chi_c, UAV.chi, UAV.r, 0, P);
%             phi_c = trackOrbit(UAV, P.orbit.center, P.orbit.radius, P.orbit.dir, P, t);

        delta_a = roll_hold(phi_c, UAV.phi, UAV.p, 0, P);
    end
  
    %----------------------------------------------------------
    % longitudinal autopilot
    

    % initialize persistent variable
    if t==0,
        if UAV.h<=P.altitude_take_off_zone,     
            altitude_state(i) = 1;
        elseif UAV.h<=h_c-P.altitude_hold_zone, 
            altitude_state(i) = 2;
        elseif UAV.h>=h_c+P.altitude_hold_zone, 
            altitude_state(i) = 3;
        else
            altitude_state(i) = 4;
        end
        initialize_integrator(i) = 1;
    end
    
    % implement state machine
    switch altitude_state(i),
        case 1,  % in take-off zone
            delta_t = 1;
%             theta_c = 30*pi/180;
            if UAV.h>=P.altitude_take_off_zone,
                altitude_state(i) = 2;
                initialize_integrator(i) = 1;
            else
                initialize_integrator(i) = 0;
            end
            
        case 2,  % climb zone
            delta_t = 1;
%             theta_c = airspeed_with_pitch_hold(Va_c, UAV.Va, initialize_integrator(i), P);
            if UAV.h>=h_c-P.altitude_hold_zone,
                altitude_state(i) = 4;
                initialize_integrator(i) = 1;
            elseif UAV.h<=P.altitude_take_off_zone,
                altitude_state(i) = 1;
                initialize_integrator(i) = 1;
            else
                initialize_integrator(i) = 0;
            end
            
        case 3, % descend zone
            delta_t = 0;
%             theta_c = airspeed_with_pitch_hold(Va_c, UAV.Va, initialize_integrator(i), P);
            if UAV.h<=h_c+P.altitude_hold_zone,
                altitude_state(i) = 4;
                initialize_integrator(i) = 1;
            else
                initialize_integrator(i) = 0;
            end
        case 4, % altitude hold zone
            delta_t = airspeed_with_throttle_hold(Va_c, UAV.Va, initialize_integrator(i), P);
%             theta_c = altitude_hold(h_c, UAV.h, initialize_integrator(i), P);
            if UAV.h<=h_c-P.altitude_hold_zone,
                altitude_state(i) = 2;
                initialize_integrator(i) = 1;
            elseif UAV.h>=h_c+P.altitude_hold_zone,
                altitude_state(i) = 3;
                initialize_integrator(i) = 1;
            else
                initialize_integrator(i) = 0;
            end
    end
    
    if t==0,
        delta_e = pitch_hold(theta_c, UAV.theta, UAV.q, 1, P);
    else
        delta_e = pitch_hold(theta_c, UAV.theta, UAV.q, 0, P);
    end

        
    %----------------------------------------------------------
    % create outputs
    
    % control outputs
    delta_i = [delta_e; delta_a; delta_r; delta_t];
    
    
    % control output
    
%     pwm_i(1) = sat(pwm_i(1),1,0);
%     pwm_i(2) = sat(pwm_i(2),1,0);
%     pwm_i(3) = sat(pwm_i(3),1,0);
%     pwm_i(4) = sat(pwm_i(4),1,0);
    delta = [delta;delta_i];
end

function output = satSgn(u)

if u>-1 && u<1
    output = u;
else
    output = sign(u);
end

% trackTarget
% track a ground target
% returns the desired roll angle
%=============================================================================
%
function phi_d = trackTarget(uav,target, P, t)

% desired roll
chi_d = atan2(target.pe - uav.pe+50, target.pn-uav.pn+50);

% chi_d = atan2(target.pe - uav.pe, target.pn-uav.pn);
% chi_d = atan2(uav.pe - target.pe, uav.pn-target.pn);

chi_d_dot = P.chi.k*(chi_d - wrapPi(uav.chi));

V = uav.Va;

phi_d = sat(atan( V/P.g*( chi_d_dot ) ), P.UAV.phibar, -P.UAV.phibar);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Autopilot functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% course_hold
%   - regulate heading using the roll command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function phi_c = course_hold(chi_c, chi, r, flag, P)
  persistent integrator;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      error_d1   = 0; % error at last sample (d1-delayed by one sample)
  end
 
  % compute the current error
  error = chi_c - chi;
  
  % update the integrator
  if abs(error)>15*pi/180,
      integrator = 0;
  else
      integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  end
  
  % proportional term
  up = P.course_kp * error;
  
  % integral term
  ui = P.course_ki * integrator;
  
  % derivative term
  ud = -P.course_kd*r;
  
  
  % implement PID control
  phi_c = sat(up + ui + ud, 45*pi/180, -45*pi/180);
  
  % implement integrator anti-windup
  if P.course_ki~=0,
    phi_c_unsat = up+ui+ud;
    k_antiwindup = P.Ts/P.course_ki;
    integrator = integrator + k_antiwindup*(phi_c-phi_c_unsat);
  end

  % update persistent variables
  error_d1 = error;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% roll_hold
%   - regulate roll using aileron
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function delta_a = roll_hold(phi_c, phi, p, flag, P)
  persistent integrator;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      error_d1   = 0; % error at last sample (d1-delayed by one sample)
  end
 
  % compute the current error
  error = phi_c - phi;
  
  % update the integrator
  integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  
  % proportional term
  up = P.roll_kp * error;
  
  % integral term
  ui = P.roll_ki * integrator;
  
  % derivative term
  ud = -P.roll_kd*p;
  
  
  % implement PID control
  delta_a = sat(up + ui + ud, 45*pi/180, -45*pi/180);
  
  % implement integrator anti-windup
  if P.roll_ki~=0,
    delta_a_unsat = up + ui + ud;
    k_antiwindup=P.Ts/P.roll_ki;
    integrator = integrator + k_antiwindup*(delta_a - delta_a_unsat);
  end
  
  % update persistent variables
  error_d1 = error;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pitch_hold
%   - regulate pitch using elevator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function delta_e = pitch_hold(theta_c, theta, q, flag, P)
  persistent integrator;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      error_d1   = 0; % error at last sample (d1-delayed by one sample)
  end
 
  % compute the current error
  error = theta_c - theta;
  
  % update the integrator
  integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  
  % proportional term
  up = P.pitch_kp * error;
  
  % integral term
  ui = P.pitch_ki * integrator;
  
  % derivative term
  ud = -P.pitch_kd * q;
  
  
  % implement PID control
  delta_e = sat(up + ui + ud, 45*pi/180, -45*pi/180);
  
  % implement integrator anti-windup
  if P.pitch_ki~=0,
    delta_e_unsat = up + ui + ud;
    k_antiwindup = P.Ts/P.pitch_ki;
    integrator = integrator + k_antiwindup*(delta_e-delta_e_unsat);
  end
  
  % update persistent variables
  error_d1 = error;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% airspeed_with_pitch_hold
%   - regulate airspeed using pitch angle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function theta_c = airspeed_with_pitch_hold(Va_c, Va, flag, P)
  persistent integrator;
  persistent differentiator;
  persistent differentiator_d1;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      differentiator = 0;
      differentiator_d1 = 0;
      error_d1   = 0; 
  end
 
  % compute the current error
  error = Va_c - Va;
  
  % update the integrator
  integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  
  % update the differentiator
  differentiator = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*differentiator_d1...
      + (2/(2*P.tau+P.Ts))*(error - error_d1);
  
  % proportional term
  up = P.airspeed_pitch_kp * error;
  
  % integral term
  ui = P.airspeed_pitch_ki * integrator;
  
  % derivative term
  ud = P.airspeed_pitch_kd * differentiator;
  
  
  % implement PID control
  theta_c = sat(up + ui + ud, 30*pi/180, -30*pi/180);
  
  % implement integrator antiwindup
  if P.airspeed_pitch_ki~=0,
    theta_c_unsat = up + ui + ud;
    k_antiwindup = P.Ts/P.airspeed_pitch_ki;
    integrator = integrator + k_antiwindup*(theta_c-theta_c_unsat);
  end

  % update persistent variables
  error_d1 = error;
  differentiator_d1 = differentiator;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% airspeed_with_throttle_hold
%   - regulate airspeed using throttle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function delta_t = airspeed_with_throttle_hold(Va_c, Va, flag, P)
  persistent integrator;
  persistent differentiator;
  persistent differentiator_d1;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      differentiator = 0;
      differentiator_d1 = 0;
      error_d1   = 0; 
  end
 
  % compute the current error
  error = Va_c - Va;
  
  % update the integrator
  integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  
  % update the differentiator
  differentiator = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*differentiator_d1...
      + (2/(2*P.tau+P.Ts))*(error - error_d1);
  
  % proportional term
  up = P.airspeed_throttle_kp * error;
  
  % integral term
  ui = P.airspeed_throttle_ki * integrator;
  
  % derivative term
  ud = P.airspeed_throttle_kd * differentiator;  
  
  P.u_trim(4) = 0.8355;
  
  % implement PID control
  delta_t = sat(P.u_trim(4)+up + ui + ud, 1, 0);
  
  % implement integrator anti-windup
  if P.airspeed_throttle_ki~=0,
    delta_t_unsat = P.u_trim(4) + up + ui + ud;
    k_antiwindup = P.Ts/P.airspeed_throttle_ki;
    integrator = integrator + k_antiwindup*(delta_t-delta_t_unsat);
  end
  
  % update persistent variables
  error_d1 = error;
  differentiator_d1 = differentiator;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% altitude_hold
%   - regulate altitude using pitch angle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function theta_c = altitude_hold(h_c, h, flag, P)
  persistent integrator;
  persistent differentiator;
  persistent differentiator_d1;
  persistent error_d1;
  % initialize persistent variables at beginning of simulation
  if flag==1,
      integrator = 0; 
      differentiator = 0;
      differentiator_d1 = 0;
      error_d1   = 0; 
  end
 
  % compute the current error
  error = h_c - h;
  
  % update the integrator
  integrator = integrator + (P.Ts/2)*(error + error_d1); % trapazoidal rule
  
  % update the differentiator
  differentiator = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*differentiator_d1...
      + (2/(2*P.tau+P.Ts))*(error - error_d1);
  
  % proportional term
  up = P.altitude_kp * error;
  
  % integral term
  ui = P.altitude_ki * integrator;
  
  % derivative term
  ud = P.altitude_kd * differentiator;
  
  
  % implement PID control
  theta_c = sat(up + ui + ud, 30*pi/180, -30*pi/180);
  
  % implement integrator anti-windup
  if P.altitude_ki~=0,
    theta_c_unsat = up + ui + ud;
    k_antiwindup = P.Ts/P.altitude_ki;
    integrator = integrator + k_antiwindup*(theta_c-theta_c_unsat);
  end
  
  % update persistent variables
  error_d1 = error;
  differentiator_d1 = differentiator;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sat
%   - saturation function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = sat(in, up_limit, low_limit)
if in > up_limit,
    out = up_limit;
elseif in < low_limit;
    out = low_limit;
else
    out = in;
end

%=============================================================================
% wrapPi
% wrap chi between [-pi, pi]
%=============================================================================
%
function chi = wrapPi(chi)
while chi > pi,
    chi = chi-2*pi;
end
while chi < -pi,
    chi = chi+2*pi;
end

%=============================================================================
% wrap2pi
% wrap chi between [0, 2*pi]
%=============================================================================
%
function chi = wrap2pi(chi)
while chi > 2*pi,
    chi = chi-2*pi;
end
while chi < 0,
    chi = chi+2*pi;
end

%=============================================================================
% unwrap
% ensures that there are not jumps of +- 2pi in the signal
%=============================================================================
%
function x = unwrap(x, x_old)
while x-x_old > pi,
    x = x-2*pi;
end
while x-x_old < -pi,
    x = x+2*pi;
end



