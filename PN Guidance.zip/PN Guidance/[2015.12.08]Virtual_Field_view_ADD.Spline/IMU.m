function [ out ] = IMU( uu,P )
%IMU Summary 
% Emulate the readings of IMU on autopilot and GPS sensors.
% 
% Last updated by
% 7/29/15 LS
%
t = uu(end);

% persistent variables that define random walk of GPS sensors
persistent eta_n;
persistent eta_e;
persistent eta_h;

    
if t<P.Ts,  % initialize persistent variables
    eta_n = 0;
    eta_e = 0;
    eta_h = 0;
else      % propagate persistent variables
    eta_n = exp(-P.beta_gps*P.Ts_gps)*eta_n + P.sigma_n_gps*randn;
    eta_e = exp(-P.beta_gps*P.Ts_gps)*eta_e + P.sigma_e_gps*randn;
    eta_h = exp(-P.beta_gps*P.Ts_gps)*eta_h + P.sigma_h_gps*randn;
end

wn = 0;
we = 0;

out=[];
for i=1:P.UAV.N
    NN = (i-1)*7;
    UAV.pn     = uu(1+NN);    % north position (m)
    UAV.pe     = uu(2+NN);    % east position (m)
    UAV.h      = uu(3+NN);    % altitude (m)
    UAV.hdot   = uu(4+NN);    % altitude rate (m/s)
    UAV.Va     = uu(5+NN);    % airspeed (m/s)
    UAV.chi    = uu(6+NN);    % course angle (rad)
    UAV.phi    = uu(7+NN);    % roll angle (rad)
    
    UAV.psi = UAV.chi;
    
%     UAV.theta = asin(UAV.hdot/UAV.Va);
           
    % simulate pressure sensors
    y_static_pres = P.rho*P.gravity*(UAV.h) + P.sigma_static_pres*randn;% altitude
    y_diff_pres = 0.5*P.rho*UAV.Va^2 + P.sigma_diff_pres*randn; % airspeed
    
    % construct North, East, and altitude GPS measurements
    y_gps_n = UAV.pn + eta_n;
    y_gps_e = UAV.pe + eta_e; 
    y_gps_h = UAV.h  + eta_h; 
    
    % construct groundspeed and course measurements
    VN = UAV.Va*cos(UAV.psi)+wn;
    VE = UAV.Va*sin(UAV.psi)+we;
    y_gps_Vg     = sqrt(VN^2 + VE^2) + P.sigma_Vg_gps*randn;
    y_gps_course = atan2(VE, VN) + P.sigma_course_gps*randn;
%     y_gps_Vg     = sqrt(VN^2 + VE^2);
%     y_gps_course = atan2(VE, VN);
   
    out = [out;y_gps_n;y_gps_e;y_gps_h;UAV.hdot;UAV.Va;UAV.chi;UAV.phi];
end

out = uu(1:7);
end

