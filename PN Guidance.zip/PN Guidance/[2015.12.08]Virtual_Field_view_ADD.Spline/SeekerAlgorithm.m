function [ output ] = SeekerAlgorithm(uu,P)
%SEEKER Summary of this function goes here
%   Detailed explanation goes here

NN = 0;
qx          = uu(NN+1);
qy          = uu(NN+2);
target_size = uu(NN+3);
target_psi  = uu(NN+4);


output = [1;qx;qy;zeros(4,1)];
end
