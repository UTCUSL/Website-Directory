function output = TrackingFilter( uu,P )
%TrackingFilter Summary of this function goes here
%   Detailed explanation goes here


persistent xhat

NN = 0;
t = uu(NN+1);

NN = NN+2;
qx = uu(1+NN);
qy = uu(2+NN);

%CFO3SPKF
%xhat = CFO3SPKF(qx, qy, t, P);

%SPKF
%xhat = SPKF(qx,qy,t,P);

%Spline
xhat = mySpline(qx,qy,t,P);

NN = NN+6;
UAV.pn     = uu(1+NN);    % north position (m)
UAV.pe     = uu(2+NN);    % east position (m)
UAV.h      = uu(3+NN);    % altitude (m)
UAV.hdot   = uu(4+NN);    % altitude rate (m/s)
UAV.Va     = uu(5+NN);    % airspeed (m/s)
UAV.chi    = uu(6+NN);    % course angle (rad)
UAV.phi    = uu(7+NN);    % roll angle (rad)

% rotation matrix converting a vector from camera frame to the level frame
% (removing roll)
UAV.theta = asin(UAV.hdot/UAV.Va);
theta = UAV.theta;
phi   = UAV.phi;

Rot_v1_to_v2 = [...
    cos(theta), 0, -sin(theta);...
    0, 1, 0;...
    sin(theta), 0, cos(theta);...
    ];    
Rot_v2_to_b = [...
    1, 0, 0;...
    0, cos(phi), sin(phi);...
    0, -sin(phi), cos(phi);...
    ];
R_b_c = [...    % body to camera -- azimuth and elevation angles are zeros.
    0, 1, 0;...
    0, 0, 1;...
    1, 0, 0];

R_v1_c = R_b_c*Rot_v2_to_b*Rot_v1_to_v2;

%%%Actual 
%p_tgt_c  = [qx;qy;P.f];

%%%Estimate
p_tgt_c = [xhat(1); xhat(2);P.f];

p_tgt_v1 = R_v1_c' * p_tgt_c;

eta = atan2(p_tgt_v1(2),p_tgt_v1(1));
xi  = -atan(p_tgt_v1(3)/sqrt(p_tgt_v1(2)^2+p_tgt_v1(1)^2));


UAV.psidot = P.g/UAV.Va*tan(UAV.phi);

%z = [eta;xi];  % measurements (from camera): eta-azimuth angle, xi-elevation angle

output = [1;eta;xi; xhat(1); xhat(2); qx; qy];

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SPKF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = SPKF(qx, qy, t, P)
    
    persistent xhat
    persistent Phat
    
    %previous x and y values for velocity estimate
    persistent xprev
    persistent yprev
    
   % z = [qx; qy; (xprev-qx)/P.Tcam; (yprev-qy)/P.Tcam];  % measurements (from camera): x-position, y-position, heading
  
    %%% Initialize Kalman Filter: start KF after 2 measurements %%%%%%%%%%%%%%%
    if t<P.Ts,
        xhat = [qx; qy; 0; 0];
        Phat = P.CFPhat0;
    end
    if mod(t-P.Ts,P.Tcam)==0 %for some reason updated +0.05 (+Ts) seconds after period
        if t<2*P.Tcam
            xhat = [qx; qy; 1; 1];
            xprev = qx; yprev = qy;
        end     
    end
    
    % prediction step
    [xhat, Phat] = spkf_predict(xhat, Phat, P.Ts, P.CFQ);
    
    % measurement update
    if((abs(qx) < 250) && (abs(qy) < 250) && (t>=2*P.Tcam))
        z = [qx; qy; (xprev-qx)/P.Tcam; (yprev-qy)/P.Tcam];
        [xhat, Phat] = spkf_update(z, xhat, Phat, P.R_o3spkf);
    end
  
    %%%%%% keep track of last position for velocity update
    if mod(t,P.Tcam)==0 
        if t>=2*P.Tcam
            xprev = qx;
            yprev = qy;
        end     
    end
    
    x = xhat;   
end


%%%  
% SPKF Predict
%%%%
function [xhat, Phat] = spkf_predict(xhat, Phat, Ts, Q)
    
    dt = Ts;
    
    At0 = [1 0 dt  0;...
           0 1  0 dt;...
           0 0  1  0; ...
           0 0  0  1];
       
    Sigmaw = sqrt(Q(end));   
    Sw = [dt^3*Sigmaw/3,             0,dt^2*Sigmaw/2,            0;...
                      0, dt^3*Sigmaw/3,            0,dt^2*Sigmaw/2; ...
          dt^2*Sigmaw/2,             0,    dt*Sigmaw,            0; ...
                      0, dt^2*Sigmaw/2,            0,    dt*Sigmaw];

% IN-ORDER SPKF Step 1: State estimate time update
    xhat = At0 * xhat;
    Phat = At0 * Phat * At0' + Sw;

end

%%
% spkf measurement update
%
function [xhat, Phat] = spkf_update(y, xhat, Phat, R)

    %% Set up weights used to generate sigma points
    h = sqrt(3);
    
    alpha_0_m = 1 - length(xhat)/(h*h);
    alpha_0_c = alpha_0_m;
    alpha_i_m = 1/(2*h*h);
    alpha_i_c = alpha_i_m;
    gamma = h;
    
    %% Generate Sigma Points
    S= chol(Phat).';
    X = xhat;
    for j=1:size(S,2),
        X = [X, xhat + gamma*S(:,j), xhat - gamma*S(:,j)];
    end
    
    %% IN-ORDER SPKF Step 2: Create output estimate

    Y = X; % output estimate
    
    yhat = alpha_0_m*Y(:,1);
    
    for j=2:size(Y,2),
        yhat = yhat + alpha_i_m*Y(:,j);
    end
    
    %% IN-ORDER SPKF Step 3: Estimator gain matrix
    
    Sigma_y = alpha_0_c*(Y(:,1)-yhat)*(Y(:,1)-yhat)' + R;
    
    for j=2:size(Y,2),
        Sigma_y  = Sigma_y + alpha_i_c*(Y(:,j)-yhat)*(Y(:,j)-yhat)'; 
    end

    Sigma_xy = alpha_0_c*(X(:,1)-xhat)*(Y(:,1)-yhat)';
    
    for j=2:size(Y,2),
        Sigma_xy  = Sigma_xy + alpha_i_c*(X(:,j)-xhat)*(Y(:,j)-yhat)'; 
    end
    
    % Kalman Gain
    L = Sigma_xy / Sigma_y;
    
    xhat = xhat + L*(y-yhat);
    Phat = Phat - L*Sigma_y*L';

    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CFO3SPKF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = CFO3SPKF(qx, qy, t, P)
    persistent xhat
    persistent Phat
    
    %previous x and y values for velocity estimate
    persistent xprev
    persistent yprev
    
    % kalman filter states and covariance for curve fitting
    persistent coef_n_N_1
    persistent coef_n_N
    persistent coef_e_N_1
    persistent coef_e_N
    persistent Cov_n_N_1
    persistent Cov_n_N
    persistent Cov_e_N_1
    persistent Cov_e_N

    y = [qx; qy; (qx-xprev)/P.Tcam; (qy-yprev)/P.Tcam];
    
    %%% Initialize Kalman Filter: start KF after 2 measurements %%%%%%%%%%%%%%%
    if mod(t-P.Ts,P.Tcam)==0 %for some reason updated +0.05 (+Ts) seconds after period
        if t<2*P.Tcam
            xhat = [qx; qy; 0; 0];
            xprev = qx;
            yprev = qy;
        end     
    end

    if t<P.Ts
        xhat = [qx; qy; 0; 0];
        Phat = P.CFPhat0;
        coef_n_N_1 = P.curvefit.x0;
        coef_n_N = P.curvefit.x0;
        coef_e_N_1 = P.curvefit.x0;
        coef_e_N = P.curvefit.x0;
        Cov_n_N_1 = P.curvefit.Cov0;
        Cov_n_N = P.curvefit.Cov0;
        Cov_e_N_1 = P.curvefit.Cov0;
        Cov_e_N = P.curvefit.Cov0;
    end



    %%% prediction step: After 2 measurements %%%%%%%%%%%%

    [xhat, Phat] = cfo3spkf_predict(xhat, Phat, P.Ts, P.CFQ);

    [quotientCurrent,modulusCurrent] = reconcileTime(t,P.curvefit.periodT);
    if modulusCurrent<P.Ts
        coef_n_N_1 = coef_n_N;
        coef_e_N_1 = coef_e_N; 
    end

     if((abs(qx) < 250)&&(abs(qy) < 250) && (t>=2*P.Tcam))
         %%% measurement update
         if round(mod(round(t*10)/10,P.Tcam)*10)/10<P.Ts && t>P.delayT  
             % calculate the xhat_old and Phat_old
             [quotientDelay,modulusDelay] = reconcileTime(t-P.delayT,P.curvefit.periodT);
             if quotientDelay < quotientCurrent % delayed measurement was taken in the previous period
                 xhat_old = [[coef_n_N_1';coef_e_N_1']*posPolyValue(modulusDelay,P)';...
                             [coef_n_N_1';coef_e_N_1']*velocityPolyValue(modulusDelay,P)'];
             else % delayed measurement was taken in the current period
                 xhat_old = [[coef_n_N';coef_e_N']*posPolyValue(modulusDelay,P)';...
                             [coef_n_N';coef_e_N']*velocityPolyValue(modulusDelay,P)'];
             end
             Phat_old = delayedCovariance(Phat,P.delayT,P);

             [xhat, Phat] = cfo3spkf_update(xhat, Phat, y, xhat_old, Phat_old, P.delayT, P.R_o3spkf);
         end
     end
    %%% curve fitting
    coef = [coef_n_N_1,coef_n_N,coef_e_N_1,coef_e_N];
    Cov_coef = [Cov_n_N_1,Cov_n_N,Cov_e_N_1,Cov_e_N];
    [coef,Cov_coef]=curveFit(modulusCurrent, coef,Cov_coef, xhat, Phat, P);
    coef_n_N_1 = coef(:,1);
    coef_n_N = coef(:,2);
    coef_e_N_1 = coef(:,3);
    coef_e_N = coef(:,4);
    Cov_n_N_1 = Cov_coef(:,1:P.curvefit.N_order+1);
    Cov_n_N = Cov_coef(:,P.curvefit.N_order+2:(P.curvefit.N_order+1)*2);
    Cov_e_N_1 = Cov_coef(:,(P.curvefit.N_order+1)*2+1:(P.curvefit.N_order+1)*3);
    Cov_e_N = Cov_coef(:,(P.curvefit.N_order+1)*3+1:(P.curvefit.N_order+1)*4);

    
    %%%%%% keep track of last position for velocity update
    if mod(t,P.Tcam)==0 
        if t>=2*P.Tcam
            xprev = qx;
            yprev = qy;
        end     
    end
    
    x = xhat;
    
    
end

%%% CFO3SPKF prediction function
function [xhat, Phat] = cfo3spkf_predict(xhat, Phat, Ts, Q)

    dt = Ts;
    
    At0 = [1 0 dt  0;...
           0 1  0 dt;...
           0 0  1  0; ...
           0 0  0  1];
       
    Sigmaw = sqrt(Q(end));   
    Sw = [dt^3*Sigmaw/3,             0,dt^2*Sigmaw/2,            0;...
                      0, dt^3*Sigmaw/3,            0,dt^2*Sigmaw/2; ...
          dt^2*Sigmaw/2,             0,    dt*Sigmaw,            0; ...
                      0, dt^2*Sigmaw/2,            0,    dt*Sigmaw];

%IN-ORDER SPKF Step 1: State estimate time update
    xhatCurrent = xhat;
    PhatCurrent = Phat;
    xhatCurrent = At0 * xhatCurrent;
    PhatCurrent = At0 * PhatCurrent * At0' + Sw;
    xhat = xhatCurrent;
    Phat = PhatCurrent;
end

%%% CFO3SPKF update function
function [xhat, Phat] = cfo3spkf_update(xhat, Phat, y,xhat_old, Phat_old, delayT, R)

    yPrior = y;
    %%% Set up weights used to generate sigma points
%     dt = delayT;
    
    h = sqrt(3);
    
    alpha_0_m = 1 - length(xhat)/(h*h);
    alpha_0_c = alpha_0_m;
    alpha_i_m = 1/(2*h*h);
    alpha_i_c = alpha_i_m;
    gamma = h;
    
    %%% Calculate xhatPrior and PhatPrior
       
%     At0 = [1 0 dt  0;...
%            0 1  0 dt;...
%            0 0  1  0; ...
%            0 0  0  1];
%        
%     Sigmaw = sqrt(Q(end));   
%     Sw = [dt^3*Sigmaw/3,             0,dt^2*Sigmaw/2,            0;...
%                       0, dt^3*Sigmaw/3,            0,dt^2*Sigmaw/2; ...
%           dt^2*Sigmaw/2,             0,    dt*Sigmaw,            0; ...
%                       0, dt^2*Sigmaw/2,            0,    dt*Sigmaw];
%     
%     xhatPrior = At0 \ xhat;
%     PhatPrior = At0 \ (Phat-Sw) * inv(At0)'; %!!! different than the paper
    
    %%% Generate Sigma Points of the prior xhat
    PhatPrior = Phat_old;
    Sprior= chol(PhatPrior).';
    xhatPrior = xhat_old;
    Xprior = xhatPrior;
    for j=1:size(Sprior,2),
        Xprior = [   Xprior, ...
                     xhatPrior + gamma*Sprior(:,j), ...
                     xhatPrior - gamma*Sprior(:,j)];
    end
    
    %%% O3 SPKF Step 2: Create prior output estimate
    Yprior = Xprior; % output estimate y=h(x).
    
    yhatPrior = alpha_0_m*Yprior(:,1);
    
    for j=2:size(Yprior,2),
        yhatPrior = yhatPrior + alpha_i_m*Yprior(:,j);
    end
    
    %%% Generate Sigma Points of the current xhat
    xhatCurrent = xhat;
    PhatCurrent = Phat;
    S= chol(PhatCurrent).';
    X = xhatCurrent;
    for j=1:size(S,2),
        X = [X, xhatCurrent + gamma*S(:,j), xhatCurrent - gamma*S(:,j)];
    end
    
    %%% O3 SPKF Step 3: Estimator gain matrix
    Sigma_yPrior = alpha_0_c*(Yprior(:,1)-yhatPrior)*(Yprior(:,1)-yhatPrior)' + R;
    
    for j=2:size(Yprior,2),
        Sigma_yPrior  = Sigma_yPrior + ...
                 alpha_i_c*(Yprior(:,j)-yhatPrior)*(Yprior(:,j)-yhatPrior)'; 
    end

    Sigma_xyPrior = alpha_0_c*(X(:,1)-xhatCurrent)*(Yprior(:,1)-yhatPrior)';
    
    for j=2:size(Yprior,2),
        Sigma_xyPrior  = Sigma_xyPrior + ...
                        alpha_i_c*(X(:,j)-xhatCurrent)*(Yprior(:,j)-yhatPrior)'; 
    end
    
    % Kalman Gain
    L = Sigma_xyPrior / Sigma_yPrior;
    
    xhatCurrent = xhatCurrent + L*(yPrior-yhatPrior);
    PhatCurrent = PhatCurrent - L*Sigma_yPrior*L';
    
    xhat = xhatCurrent;
    Phat = PhatCurrent;

    
end

%%% CFO3SPKF curve fitting function
function [coef,Cov_coef]=curveFit(modulusCurrent,coef,Cov_coef, xhat,Phat, C)

    coef_n_N_1 = coef(:,1);
    coef_n_N = coef(:,2);
    coef_e_N_1 = coef(:,3);
    coef_e_N = coef(:,4);
    Cov_n_N_1 = Cov_coef(:,1:C.curvefit.N_order+1);
    Cov_n_N = Cov_coef(:,C.curvefit.N_order+2:(C.curvefit.N_order+1)*2);
    Cov_e_N_1 = Cov_coef(:,(C.curvefit.N_order+1)*2+1:(C.curvefit.N_order+1)*3);
    Cov_e_N = Cov_coef(:,(C.curvefit.N_order+1)*3+1:(C.curvefit.N_order+1)*4);

    
    if  (modulusCurrent<C.Ts)
        coef_n_N_1 = coef_n_N;
        coef_e_N_1 = coef_e_N;
        Cov_n_N_1 = C.curvefit.Cov0;
        Cov_n_N = C.curvefit.Cov0;
        Cov_e_N_1 = C.curvefit.Cov0;
        Cov_e_N = C.curvefit.Cov0;
    end
    
    pn = xhat(1);
    pe = xhat(2);
    vn = xhat(3);
    ve = xhat(4);
     
    CC    = posPolyValue(modulusCurrent,C);
    CCdot = velocityPolyValue(modulusCurrent,C);
    
    % update using position info
    L_n = Cov_n_N*CC'/(C.curvefit.R + CC*Cov_n_N*CC');
    L_e = Cov_e_N*CC'/(C.curvefit.R + CC*Cov_e_N*CC');
%     L_n = Cov_n_N*CC'/(Phat(1,1) + CC*Cov_n_N*CC');
%     L_e = Cov_e_N*CC'/(Phat(2,2) + CC*Cov_e_N*CC');
    Cov_n_N = (eye(C.curvefit.N_order+1) - L_n*CC)*Cov_n_N;
    Cov_e_N = (eye(C.curvefit.N_order+1) - L_e*CC)*Cov_e_N;
    
    coef_n_N = coef_n_N + L_n*(pn-CC*coef_n_N);
    coef_e_N = coef_e_N + L_e*(pe-CC*coef_e_N);
    
    % update using velocity info
    L_n = Cov_n_N*CCdot'/(C.curvefit.R + CCdot*Cov_n_N*CCdot');
    L_e = Cov_e_N*CCdot'/(C.curvefit.R + CCdot*Cov_e_N*CCdot');
%     L_n = Cov_n_N*CCdot'/(Phat(3,3) + CCdot*Cov_n_N*CCdot');
%     L_e = Cov_e_N*CCdot'/(Phat(4,4) + CCdot*Cov_e_N*CCdot');
    Cov_n_N = (eye(C.curvefit.N_order+1) - L_n*CCdot)*Cov_n_N;
    Cov_e_N = (eye(C.curvefit.N_order+1) - L_e*CCdot)*Cov_e_N;
    
    coef_n_N = coef_n_N + L_n*(vn-CCdot*coef_n_N);
    coef_e_N = coef_e_N + L_e*(ve-CCdot*coef_e_N); 
       
    coef = [coef_n_N_1,coef_n_N,coef_e_N_1,coef_e_N];
    Cov_coef = [Cov_n_N_1,Cov_n_N,Cov_e_N_1,Cov_e_N];
    
end

%%% calculate the quotient and modulus of t/period
function  [quotient,modulus] = reconcileTime(t, period)
    quotient = floor(t/period);
    modulus  = round(mod(round(t*10)/10,period)*10)/10;
end


% calculate the position polynomial vector using time tt
function y = posPolyValue(ttt,C)
    y = 1;
    for j = 1:C.curvefit.N_order
        y = [y,ttt^j];
    end
end

% calculate the velocity polynomial vector using time tt
function y = velocityPolyValue(ttt,C)
    y = 0;
    for j = 1:C.curvefit.N_order
        y = [y,j*ttt^(j-1)];
    end
end

function Phat_old = delayedCovariance(Phat,delayT,C)
    dt = delayT;

    At0 = [1 0 dt  0;...
        0 1  0 dt;...
        0 0  1  0; ...
        0 0  0  1];

    Sigmaw = sqrt(C.Q(end));
    Sw = [dt^3*Sigmaw/3,             0,dt^2*Sigmaw/2,            0;...
        0, dt^3*Sigmaw/3,            0,dt^2*Sigmaw/2; ...
        dt^2*Sigmaw/2,             0,    dt*Sigmaw,            0; ...
        0, dt^2*Sigmaw/2,            0,    dt*Sigmaw];
    
    Phat_old = At0 \ (Phat-Sw) * inv(At0)';
    Phat_old = Phat*0.1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Spline Extrapolation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = mySpline(qx,qy,t,P)
    %spline data
    persistent pastData
    persistent projx
    persistent projy
    persistent ax
    persistent bx
    persistent cx
    persistent dx
    persistent ay
    persistent by
    persistent cy
    persistent dy
    
    if t==0
         projx = 0;
         projy = 0;
         pastData = zeros(4,3);
         pastData(4,:) = [qx qy t];
    end
    
    %extrapolate 
    if(mod(t,P.Ts) == 0) && (t > 4*P.Tcam),  
        %project x and y based on spline coeffs
        dt = P.Tcam+(t-pastData(4,3));
        projx = dx + dt*(cx + dt*(bx + dt*ax));
        projy = dy + dt*(cy + dt*(by + dt*ay));

    end
    
    if((abs(qx) < 250)&&(abs(qy) < 250))
        if (mod(t,P.Tcam) == 0)&&(mod(t,P.Tcam)~=(7||8||9)),
            pastData(1:3,:) = pastData(2:4,:);
            pastData(4,:) = [qx qy t];
            projx = qx;
            projy = qy;
            %%% Calculate new coeffecients.
            if t>=4*P.Tcam
                [ax, bx, cx, dx] = splineCoeff(pastData(:,3), pastData(:,1), P);
                [ay, by, cy, dy] = splineCoeff(pastData(:,3), pastData(:,2), P);
            end
        end
    end     

    x = [projx; projy; 0; 0];
end

function [a_nm1, b_nm1, c_nm1, d_nm1] = splineCoeff(t,y,P)
% This function calculates the spline coefficients
% for data x at time t.

dim = length(t);

M = zeros(dim);
dx = zeros(dim-1,1);
dy = zeros(dim-1,1);
Yout = zeros(dim,1);
S = zeros(dim,1);

%find time difference(dx) and position difference(dy)
for i=1:dim-1
    dx(i) = t(i+1)-t(i);
    dy(i) = y(i+1)-y(i);
end

for i=2:dim-1
    M(i,i-1:i+1) = [dx(i-1) 2*(dx(i-1)+dx(i)) dx(i)];
    Yout(i) = 3*(dy(i)/dx(i)-dy(i-1)/dx(i-1));
end

% Set Endpoint Conditions
% not-a-knot 
M(1,1:3) = [dx(2) -(dx(1)+dx(2)) dx(1)];
M(dim, dim-2:dim) = [dx(dim-1) -(dx(dim-2)+dx(dim-1)) dx(dim-2)];

S(:,2) = M\Yout;
for i=1:dim-1
    S(i,3) = (S(i+1,2)-S(i,2))/(3*dx(i));
    S(i,1) = dy(i)/dx(i)-dx(i)*(2*S(i,2)+S(i+1,2))/3;
end

a_nm1 = S(dim-1,3);
b_nm1 = S(dim-1,2);
c_nm1 = S(dim-1,1);
d_nm1 = y(dim-1);

end

