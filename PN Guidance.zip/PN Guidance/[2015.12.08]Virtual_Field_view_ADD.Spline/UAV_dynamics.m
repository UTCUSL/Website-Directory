%% UAV_dynamics.m
%%
%% Generate 3D UAV motion based on a nonlinear kinematic model.
%%
%% Modified:
%%    14/08/20 - Liang Sun
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sys,x0,str,ts] = UAV_dynamics(t,x,u,flag,P)
%
switch flag,
    
    %%%%%%%%%%%%%%%%%%
    % Initialization %
    %%%%%%%%%%%%%%%%%%
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes(P);
        
        %%%%%%%%%%%%%%%
        % Derivatives %
        %%%%%%%%%%%%%%%
    case 1,
        sys=mdlDerivatives(t,x,u,P);
        
        %%%%%%%%%%
        % Update %
        %%%%%%%%%%
    case 2,
        sys=mdlUpdate(t,x,u);
        
        %%%%%%%%%%%
        % Outputs %
        %%%%%%%%%%%
    case 3,
        sys=mdlOutputs(t,x,u,P);
        
        %%%%%%%%%%%%%%%%%%%%%%%
        % GetTimeOfNextVarHit %
        %%%%%%%%%%%%%%%%%%%%%%%
    case 4,
        sys=mdlGetTimeOfNextVarHit(t,x,u);
        
        %%%%%%%%%%%%%
        % Terminate %
        %%%%%%%%%%%%%
    case 9,
        sys=mdlTerminate(t,x,u);
        
        %%%%%%%%%%%%%%%%%%%%
        % Unexpected flags %
        %%%%%%%%%%%%%%%%%%%%
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
        
end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes(P)
%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 7*P.UAV.N;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 7*P.UAV.N;
sizes.NumInputs      = 3*P.UAV.N+3;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%

x0 = P.UAV.x0;

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,uu,P)
% process states
xdot = [];
wind = uu(end-2:end); % steady wind
wind_n = wind(1);
wind_e = wind(2);
wind(4:6,1) = 0; % gust

for i = 1:P.UAV.N
    NN = (i-1)*7;
    pn     = x(1+NN);    % north position (m)
    pe     = x(2+NN);    % east position (m)
    h      = x(3+NN);    % altitude (m)
    hdot   = x(4+NN);    % altitude rate (m/s)
    Va     = x(5+NN);    % airspeed (m/s)
    chi    = x(6+NN);    % course angle (rad)
    phi    = x(7+NN);    % roll angle (rad)
    
    NN = (i-1)*3;
    Va_c  = uu(1+NN);
    phi_c = uu(2+NN);
    h_c   = uu(3+NN);
    
    % solve for heading angle, psi. Project the wind vector onto the unit
    % vector that is perpendicular to the ground velocity vector. The
    % flight path angle, gam, is assumed to be zero.
    psi = chi - asin( (-wind_n*sin(chi)+wind_e*cos(chi))/Va );
    
    % compute groundspeed
    pndot   = Va*cos(psi) + wind_n;
    pedot   = Va*sin(psi) + wind_e;
    Vadot   = P.b_Va*(Va_c-Va);
        
    % don't let climb rate exceed Va*sin(\gamma_max)
    gamma_max = 30*pi/180;
    hddot   = -P.b_hdot*hdot + P.b_h*(h_c-h);

    Vg = norm(Va*[cos(psi);sin(psi)]+[wind_n;wind_e]);
    chidot = P.g/Vg*tan(phi);
    phidot = P.b_roll*(phi_c-phi);
    phidot = lim_sat(phi,phidot,P.UAV.phibar,P.UAV.phidotbar);
        
    if (hdot>=Va*sin(gamma_max)) & (hddot>0),
        hddot = 0;
    elseif (hdot<=-Va*sin(gamma_max)) & (hddot<0),
        hddot = 0;
    end
    
    xdot = [xdot;...
        pndot; pedot; hdot;...
        hddot; Vadot;chidot;phidot];
end



sys = xdot;

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u,P)

sys = x;

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate

%
%=============================================================================
% sat
% saturates the input between high and low
%=============================================================================
%
function out=sat(in, low, high)

if in < low,
    out = low;
elseif in > high,
    out = high;
else
    out = in;
end

% end sat
%
%=============================================================================
% lim_sat
% the integration variable is limited to be within a certain interval and
% the rate of increase is saturated
%=============================================================================
%
function state_dot = lim_sat(state, input, state_limit, rate_limit)

if ((state>=state_limit)&&(input>0))||((state<=-state_limit)&&( input<0))
    state_dot = 0;
else
    state_dot = sat(input, -rate_limit,rate_limit);
end
