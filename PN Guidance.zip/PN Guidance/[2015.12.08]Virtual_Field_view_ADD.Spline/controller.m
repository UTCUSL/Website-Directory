%% controller.m
%%
%% Calculate control inputs to UAV_dynamics for target tracking mission.
%%
%% Modified:
%%    14/08/20 - Liang Sun
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function y = controller(uu,P)
%
% autopilot for UAV
%
% Modification History:
%   08/20/2014 Liang Sun

persistent target_chi_dot_k1 target_chi_ddot


% initialize persistent variables at beginning of simulation
t = uu(1);
% NN = 1;
% camera.qx   = uu(1+NN);
% camera.qy   = uu(2+NN);
% camera.target_size = uu(3+NN);
% camera.target_chi  = uu(4+NN);

NN = 1;
% target.pn      = uu(1+NN);    % north position (m)
% target.pe      = uu(2+NN);    % east position (m)
% target.pd      = uu(3+NN);    % position down (negative of altitude) (m)
% target.V      = uu(4+NN);    % linear speed
% target.chi    = uu(5+NN);    % heading (rad)
% target.Vdot   = uu(6+NN);    % Vdot
% target.chidot = uu(7+NN);    % chidot

target.kappa  = uu(1+NN);    % north position (m)
% target.kappa = 0;
target.eta    = uu(2+NN);    % east position (m)
target.xi     = uu(3+NN);    % position down (negative of altitude) (m)
target.V      = uu(4+NN);    % linear speed
target.chi    = uu(5+NN);    % heading (rad)
target.Vdot   = uu(6+NN);    % Vdot
target.chidot = uu(7+NN);    % chidot

target.sigma = 30+2*sin(t);

% differentiate chidot
if t<P.Ts
    target_chi_ddot=0;
    target_chi_dot_k1 = target.chidot;
else
    
    target_chi_ddot = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*target_chi_ddot...
        + (2/(2*P.tau+P.Ts))*(target.chidot - target_chi_dot_k1);
    target_chi_dot_k1 = target.chidot;
end
% target.chi_ddot = target_chi_ddot;
target.chi_ddot = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UAV states
cmd = []; % output of the controller

for i=1:P.UAV.N
    NN = 1+7+(i-1)*7;
    UAV.pn     = uu(1+NN);    % north position (m)
    UAV.pe     = uu(2+NN);    % east position (m)
    UAV.h      = uu(3+NN);    % altitude (m)
    UAV.hdot   = uu(4+NN);    % altitude rate (m/s)
    UAV.Va     = uu(5+NN);    % airspeed (m/s)
    UAV.chi    = uu(6+NN);    % course angle (rad)
    UAV.phi    = uu(7+NN);    % roll angle (rad)
    
    UAV.theta = asin(UAV.hdot/UAV.Va);
    epsilon = 0.5;
    epsilon_theta = 0.1;
    B0 = 0.05;
    B0_theta = 5;
    % sliding mode controller
    kappa_max = UAV.Va/30;
    theta_dot = -(kappa_max*abs(cos(UAV.theta)*cos(target.eta)*sin(target.xi)-sin(UAV.theta)*cos(target.xi))+B0_theta) ...
               *satSgn((UAV.theta-target.xi)/epsilon_theta);
            
    theta_c = UAV.theta+P.Ts*theta_dot;
    h_c = UAV.h+UAV.Va*sin(theta_c);
%     h_c = P.height_d + 5*sin(t);
    Va_c = P.UAV.V;
     
%     phi_c = trackOrbit(UAV, P.orbit.center, P.orbit.radius, P.orbit.dir, P, t);
%     phi_c = trackTarget(UAV,target,P,t);
    
    psidot_c = (kappa_max*abs(cos(UAV.theta)*cos(target.eta)/cos(target.xi))+B0) *satSgn((target.eta)/epsilon);
    phi_c = atan(psidot_c*UAV.Va/P.g);
%     phi_c = 0;
    cmd = [cmd;Va_c;phi_c;h_c];
end
y = [cmd;theta_dot];

function output = satSgn(u)

if u>-1 && u<1
    output = u;
else
    output = sign(u);
end

% trackTarget
% track a ground target
% returns the desired roll angle
%=============================================================================
%
function phi_d = trackTarget(uav,target, P, t)

% desired roll
chi_d = atan2(target.pe - uav.pe+50, target.pn-uav.pn+50);

% chi_d = atan2(target.pe - uav.pe, target.pn-uav.pn);
% chi_d = atan2(uav.pe - target.pe, uav.pn-target.pn);

chi_d_dot = P.chi.k*(chi_d - wrapPi(uav.chi));

V = uav.Va;

phi_d = sat(atan( V/P.g*( chi_d_dot ) ), P.UAV.phibar, -P.UAV.phibar);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Autopilot functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sat
%   - saturation function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = sat(in, up_limit, low_limit)
if in > up_limit,
    out = up_limit;
elseif in < low_limit;
    out = low_limit;
else
    out = in;
end

%=============================================================================
% wrapPi
% wrap chi between [-pi, pi]
%=============================================================================
%
function chi = wrapPi(chi)
while chi > pi,
    chi = chi-2*pi;
end
while chi < -pi,
    chi = chi+2*pi;
end



